# 31. Immutable Blob values {#blob-values}

## Conceptual integrity

A row identifies a song by its table and primary key; its `content: Blob` field is one exact sequence of bytes. Changing a title does not change those bytes. Replacing the recording replaces that field's value, not the meaning of Blob. Git snapshots select the corresponding program, schema, records and content together. There is no separate media database, attachment identity, or binary history graph.

**ORNA-BLOB-001** `Blob` MUST denote an immutable finite sequence of octets. It MUST NOT require a filename, path, media type, owner row, URL, timestamp or mutable current-version identity.

**ORNA-BLOB-002** Inline and Git-backed Blob representations MUST expose the same logical type and bytes. `Bytes`, `File`, `Asset` and `Clob` MUST NOT be introduced as additional intrinsic synonyms or mandatory tables by this release. An application MAY define ordinary records with those names. Existing `sys.File`/`sys.FileRef` catalogue identities remain repository/source-file observations; they are not renamed to Blob and do not become a compulsory media registry. `Str` remains text, with its existing Unicode semantics.

**ORNA-BLOB-003** A Blob field MUST be permitted wherever the existing serialisable Blob type is admitted, including nested lists, records, Options and nominal values. Primary-key admissibility is unchanged; this release adds no Blob primary-key representation.

```orna
pub table Song(id: Str) {
    title: Str,
    artist: Str,
    content: Blob,
}

pub fn add(id: Str, title: Str, artist: Str, content: Blob) {
    Song.insert({ id: id, title: title, artist: artist, content: content });
}
```

The table key identifies a row within its table and database. It is not a newly introduced UUID on every value. Version 1 selects a title and Blob A; version 2 may select another title and the same Blob A; version 3 may select Blob B. Neither Blob is mutated by the change.

## Content identity and equality

The content commitment is the pair `(length, SHA256(bytes))`. The SHA-256 input is exactly the raw byte sequence: no filename, media type, chunk boundaries, Git object header, compression or repository identity. Length is the exact nonnegative byte count. The external spelling of the digest is `sha256:` followed by 64 lowercase hex digits. The public `Digest` value retains its existing tag-60025 encoding.

**ORNA-BLOB-004** Content identity MUST be independent of storage layout, Git SHA-1/SHA-256 object mode, chunking policy, location and representation rewrites. A content Git tree OID MUST NOT be substituted for the content digest.

**ORNA-BLOB-005** Logical equality MUST remain byte-sequence equality. Different lengths or different correctly validated content commitments imply inequality. Equal digests alone MUST NOT override detected unequal bytes. Independently obtained equal-digest values without a shared verified content witness require bounded streaming comparison before exact equality can be asserted; inability to obtain bytes is an error, not false or true. Repeated references to the same admitted immutable value may compare equal without rereading it.

**ORNA-BLOB-006** An import encountering an existing content ID MUST either reuse a validated identical object or validate equality before coalescing independently supplied bytes. A detected digest collision MUST fail as `sys.blob.collision`; it MUST NOT overwrite the existing object or invent another spelling for it.

A committed descriptor is a commitment, not proof that all its promised chunks were downloaded or that its claimed whole-content digest has been recomputed. A range read validates its own bytes against the snapshot's chunk descriptors. A full verification establishes the complete digest. The implementation records this distinction; it never calls an absent object verified.

## Laziness throughout the engine

**ORNA-BLOB-007** Loading a row, inspecting a Blob summary, reading its length/digest, copying the value between same-database records, or changing another field MUST NOT hydrate the Blob payload merely to build an in-memory `Vec<u8>`, compute a display string or re-encode the row. Metadata/index/descriptor reads remain permitted. Reading or comparing actual content may require I/O and may fail explicitly.

**ORNA-BLOB-008** A held Blob MUST retain its exact immutable content and resolution context for its owning activation/session/pin lifetime. It MUST NOT resolve through a later HEAD, working-tree path or row value. Expiration/unavailability MUST be reported; it MUST NOT rebind to newer bytes.

**ORNA-BLOB-009** Codecs that promise complete bytes MUST preserve that promise. OVB-1 Blob remains a CBOR byte string; canonical portable Orna text remains padded Base64 under a Blob type witness. A stored reference is not silently substituted on these interfaces. Full encoding MAY stream; if a sink or protocol cannot admit the length, the operation MUST fail before successful output or provide the explicitly specified retained-without-rich-result outcome for an already committed operation.

**ORNA-BLOB-010** Ordinary Blob inspection MUST report safe type/length/content identity without dumping payloads or invoking remote analysis. A missing payload MUST NOT be presented as an empty Blob. Media type is an interpretation or application field, not part of Blob identity.

## Public core operations

`api/sys.json` owns the exact signatures. All integer offsets/lengths are mathematical integers, never rounded Float. The maximum content length in OGB-1 is 2^63−1 bytes. The bounded whole-value I/O limit for the following operations is 8 MiB (8,388,608 bytes). Implementations may provide smaller advertised operating quotas, but may not silently return a successful truncated value.

| Operation | Contract |
|---|---|
| `sys.blob.length(value)` | Exact committed byte length, no payload fetch. |
| `sys.blob.digest(value)` | Raw-content SHA-256 commitment, not a claim of complete verification. |
| `sys.blob.read(value, offset, length)` | Return a bounded Blob of at most length bytes, clipped at EOF. No decoder is run. |
| `sys.blob.verify(value)` | Incrementally verify all required chunks, total length and whole-content digest; return Unit only on success. |
| `sys.blob.from_bytes(values)` | Construct a bounded Blob from Int elements each in 0…255. |
| `sys.blob.to_bytes(value)` | Explicitly materialise a bounded list of octet-valued Int. |
| `sys.blob.begin(expected_length, max_bytes)` | Create an activation/session-owned, nonserialisable writer. |
| `sys.blob.append(writer, part)` | Append one bounded Blob, in order. No final value is exposed. |
| `sys.blob.finish(writer)` | Seal and protect the complete immutable Blob; does not insert a user row or publish a branch. |
| `sys.blob.abort(writer)` | Abandon unfinished capture; never delete a returned/committed value. |
| `sys.blob.capture_file(root, path, max_bytes)` | Host-authorised regular-file capture using the same writer/durability machinery. |
| `sys.blob.resource(path)` | Read a safe package-relative resource in the caller's selected package snapshot, not today's host filesystem. |

**ORNA-BLOB-011** `read` MUST reject negative arguments, `offset > length(value)`, and requested lengths above 8 MiB before reading. `offset == length(value)` or requested length zero returns an empty Blob. Addition MUST use checked arithmetic. EOF clipping MUST be explicit in the returned value's length; failures MUST NOT be converted into an EOF result.

**ORNA-BLOB-012** Range reading MUST fetch only necessary metadata and complete chunks intersecting the requested range, plus a separately bounded, observable read-ahead allowance. Git fetches whole objects: an implementation MUST NOT promise byte-exact network usage. Returned bytes MUST be checked against the selected descriptor and chunk digest before they are exposed.

**ORNA-BLOB-013** A `sys.BlobWriter` MUST be scoped to one owner/runtime generation and serialised against concurrent append/finish/abort. It MUST NOT be stored, encoded as an operational value, or reconstructed by accepting an identifier from a remote client. Its states are open, finished and aborted. Append after termination fails. Finish is idempotent for the same finished writer while retained; abort after finish is an idempotent no-op. Finish after abort fails. Cancellation aborts unfinished writers and joins cleanup.

**ORNA-BLOB-014** `begin` MUST reject negative or out-of-profile limits, an expected length greater than `max_bytes`, and an expected length outside the profile. Append MUST enforce the total bound before acceptance. Finish MUST check the exact expected length when supplied. An unknown length is counted while streaming; no temporary file may bypass the bound.

**ORNA-BLOB-015** Blob acquisition/hydration is not an arbitrary host effect when it resolves already selected immutable repository content. It MUST obey the caller's network/offline policy, budgets and cancellation. Speculative eager REPL previews MUST NOT initiate hydration; explicit evaluation may. `capture_file` is an external read and remains forbidden in historical evaluation, presenters, assertions and read-only watches.

These are the minimal public storage/execution capabilities. Optional `std.io.fs.read_blob` is an ordinary wrapper over `capture_file`; there is not a second `std.fs` primitive or a devtools-specific loader. The native host retains durability, safe object access and transaction enforcement. Library wrappers do not grant wider effects.

## Semantic digests without accidental hydration

**ORNA-BLOB-016** Repository-format-2 row identity MUST use the schema-directed SOV-2 substitution and `orna.row.v2` domain in [Git-native blob storage](#blob-storage). It MUST NOT hash Git layout OIDs or read unchanged payload bytes on a metadata-only update. Legacy row/argument/request identities retain their original versioned algorithms.

**ORNA-BLOB-017** Cross-format semantic comparison MUST compare decoded logical values, not unequal v1/v2 digest bytes. Rewriting storage or upgrading a representation MUST NOT emit logical row mutations merely because a digest coordinate changed.

**ORNA-BLOB-018** Materialised OVB-1 request fingerprints and consumer argument identities MUST remain unchanged. A large Blob cannot be passed through a v1 message by smuggling a storage reference into a byte-string slot. Use a typed row/action reference plus a separately authorised content read, or an explicit later protocol. Such a reference never itself grants access.

**ORNA-BLOB-019** Transferring a Blob into an independent database MUST establish and protect the destination's complete reference closure before acknowledging its row commit. The value MUST NOT become a hidden dependency on the original user's local path or unadvertised content service.
