#!/usr/bin/env python3
"""Build the complete source edition; no engine claims and no PDF relabelling."""
from pathlib import Path
import hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[1]
def load(p):return json.loads((R/p).read_text())
def save(p,x):
    f=R/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def main():
    subprocess.run([sys.executable,str(R/'tools/generate_api_reference.py')],check=True,cwd=R)
    manifest=load('source/manifest.json'); requirements=[]
    for chapter in manifest:
        for number,line in enumerate((R/chapter['file']).read_text().splitlines(),1):
            m=re.match(r'\*\*(ORNA-[A-Z0-9-]+)\*\*\s+(.+)',line)
            if m:requirements.append({'id':m[1],'chapter':chapter['id'],'source':chapter['file'],'line':number,'text':m[2]})
    if len({r['id'] for r in requirements})!=len(requirements):raise SystemExit('Duplicate requirement definitions')
    save('tests/requirements.json',requirements)
    scenarios=load('tests/scenarios.json')['scenarios'];evidence=[]
    for r in requirements:
        linked=[{'kind':'implementation-scenario','status':'not-executed','subject':s['id'],'path':'tests/scenarios.json','oracle':s['then']} for s in scenarios if r['id'] in s['requirements']]
        if not linked:linked=[{'kind':'implementation-conformance obligation','status':'not-executed','subject':r['id'],'oracle':r['text']}]
        evidence.append({'requirement':r['id'],'chapter':r['chapter'],'statement':r['text'],'implementation_result':'not-executed','tests':linked,'full_implementation_coverage_claimed':False})
    save('tests/requirement-evidence.json',{'version':'1.1.0','meaning':'Implementation status remains not-executed for every obligation. Independently scoped Python/native-Git/publication observations are in evidence/, not substituted for engine conformance. A linked scenario is a test oracle, not an executed proof.','requirements':evidence})
    baseline={x['id']:x for x in load('provenance/parent-requirements.json')};now={x['id']:x for x in requirements}
    save('provenance/requirement-changes.json',{'parent':'1.0.0','current':'1.1.0','retained':len(set(baseline)&set(now)),'added':[r for r in requirements if r['id'] not in baseline],'revised':[{'id':x,'before':baseline[x]['text'],'after':now[x]['text']} for x in baseline if x in now and baseline[x]['text']!=now[x]['text']],'removed':sorted(set(baseline)-set(now))})
    title='''# Orna 1.1.0 {#orna-specification}

**Language, runtime and repository specification — source edition.**

Publication date: 4 October 2026. Conceptual integrity is the governing design principle.

This edition retains executable Git snapshots and adds immutable, lazy Blob values stored in native Git trees. The format and migration coordinates are explicit; OVB-1 and `orna.present.v1` remain unchanged. The new source-hosted application requirements prioritise a small real table/console/content demonstration, not a new styling or reactive framework.

**Evidence boundary:** this is a specification, not a release of the Orna database engine. Python model, syntax and isolated native-Git checks do not establish implementation conformance. The complete ordered source chapters, API, profiles, tests, migration instructions and implementation goal are included.

[README](README.md) · [Change log](CHANGELOG.md) · [Migration](MIGRATION.md) · [Implementation goal](implementation/ORCHESTRATOR.md) · [Validation](evidence/VALIDATION.md)

'''
    book=title+'\n\n'.join((R/c['file']).read_text().strip() for c in manifest)+'\n'
    (R/'Orna-1.1.0.md').write_text(book)
    cmd=['pandoc','Orna-1.1.0.md','--from=markdown+fenced_divs+header_attributes','--to=html5','--standalone','--toc','--toc-depth=2','--metadata=title:Orna 1.1.0 — Language, runtime and repository specification','--css=publication/spec.css','--output=index.html']
    subprocess.run(cmd,cwd=R,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    print(f'Built {len(manifest)} chapters, {len(requirements)} requirements, {len(scenarios)} scenario oracles; engine execution not claimed.')
if __name__=='__main__':main()
