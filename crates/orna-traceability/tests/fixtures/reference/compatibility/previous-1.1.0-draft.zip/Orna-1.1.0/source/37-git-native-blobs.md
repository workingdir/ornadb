# 32. Git-native blob storage and lazy snapshots {#blob-storage}

## Profiles and feature negotiation

This chapter defines **OGB-1** (Orna Git Blob representation), **ORR-2** (repository row data), **ROV-2** (repository value encoding), **SOV-2** (semantic-value substitution), and **compact-storage-v2**. These are physical/storage coordinates. OVB-1 and `orna.present.v1` are not renamed or extended.

**ORNA-OGB-001** A repository using externalised Blob values MUST select repository format 2 before any such value becomes visible. Its `.orna/format.orna` MUST contain the exact capability record below. Unknown required coordinates fail before decoding rows or accepting writes. Repository-format-1 remains readable under its original encodings; an engine version number alone does not upgrade a database.

```text
{
  repository_format: 2,
  row_profile: "ORR-2",
  blob_profile: "OGB-1",
  semantic_profile: "SOV-2",
  compact_profile: "compact-storage-v2",
}
```

This format-2 record is closed. Older format-1 metadata is interpreted by its own profile, not by guessing compatible fields. Database UUID, allocator watermarks and checkpoint records retain their owning formats. Existing tables may retain format-1 compact segments: every segment declares its own decoding coordinate.

## One Git object graph

**ORNA-OGB-002** Blob descriptors, index nodes and chunks MUST be ordinary Git blobs/trees in the database's object database. Every published content dependency MUST be reachable through real Git tree entries from the database commit. Strings containing OIDs do not establish Git reachability. OGB-1 MUST NOT require LFS, an alternate content protocol, or a proprietary commit graph.

For a raw-content digest `abcdef…`, the snapshot-owned root is:

```text
.orna/blobs/ab/cdef…/           # first 2 hex digits, then remaining 62
    meta                      # small descriptor Git blob
    data/                     # indexed content Git tree
        index                 # directory index Git blob
        000                   # chunk or child tree
        001
        ...
```

The digest path is independent of filename, MIME type and row key. Several rows can share one root. A changed layout for the same content uses the same digest path in a newer commit. Old commits retain their original trees. The published tree need not be materialised into the ordinary working directory; sparse checkout should normally exclude managed chunk paths.

**ORNA-OGB-003** Each visible snapshot MUST resolve every external Blob token, including nested fields and committed preserved payloads, to one matching content root in that snapshot. Retaining extra unreferenced roots is permitted but MUST be observable as retained physical content, not silently presented as user records. Removing a root from HEAD requires a complete dependency proof; old commits and local pins still retain their roots.

## Binary descriptors

Descriptors use the deterministic CBOR subset of OVB-1: definite arrays, unsigned shortest integers, byte strings and null, with no tags or maps. They are storage records, not user Blob values. The 64 KiB bound applies independently to each metadata/index blob. Git tree entries use mode `100644` for blobs and `040000` for trees; no symlinks, executable bits, submodules or duplicate names are allowed inside a content root.

`meta` is exactly:

```text
[1, content_sha256_bytes32, total_length_uint, data_tree_oid_bytes]
```

The OID width is 20 in a Git SHA-1 repository and 32 in a Git SHA-256 repository. The root has exactly `meta` and `data`, and the descriptor's OID must equal the `data` tree entry.

Each data node has an `index` and consecutively named children `000`, `001`, …, `0ff` (three lowercase hexadecimal digits). Its index is exactly:

```text
[1, height_uint, total_length_uint, entries]

leaf entry:     [exclusive_end_offset, chunk_git_oid_bytes, chunk_sha256_bytes32]
internal entry: [exclusive_end_offset, child_tree_oid_bytes, null]
```

Offsets are relative to the start of this node; each start is the previous end, initially zero. A leaf has height 0 and children are raw Git blobs. An internal node has positive height and children are trees of height one less. The entry at ordinal i must match the actual Git child named by that ordinal. Entries are nonempty, at most 256, with strictly increasing offsets ending at the node length. A child length must equal the parent's corresponding interval. Internal index total lengths are recursively verifiable. Lengths and offsets are at most 2^63−1. Maximum height is 8; readers enforce this before recursion.

The empty Blob has one height-0 data node with length 0 and entries `[]`; there are no zero-length chunk entries. Nonempty chunks are at most 1 MiB. Minimum chunk size is a writer policy, not a reader assumption; this permits bounded final chunks and alternative interoperable writers. An internal node may have one child only as a final group; canonical writers collapse a one-child root.

**ORNA-OGB-004** Readers MUST validate array arity, canonical CBOR, integer widths/ranges, entry count/order, Git modes/names/OIDs, height, total length and SHA-256 widths at each visited node. A full verifier MUST check all nodes and recompute the raw-content digest. No successful partial read may be described as full verification.

**ORNA-OGB-005** A range reader MUST descend using half-open byte intervals, fetch only overlapping subtrees/chunks within the read-ahead policy, check each visited child's interval and verify every returned chunk against its Git OID and SHA-256. Malformed structure, a missing unpromised object and unavailable promised content MUST remain distinguishable outcomes.

The balanced canonical writer groups consecutive chunks into leaf nodes of up to 256 entries, then consecutive nodes into internal groups of up to 256 until one root remains. `meta` refers to this data root. Nodes are ordinary immutable trees; readers need not reconstruct the file by replaying earlier versions.

## Reference chunking policy GEAR-1

This is the default writer policy, not a new semantic type. A different disclosed chunking policy can write the same OGB-1 layout and must not change content identity. GEAR-1 parameters are minimum 65,536 bytes, cut-mask `(1 << 18) - 1`, maximum 1,048,576 bytes; chunks reset the accumulator. A final nonempty remainder is emitted. Empty input has no chunks.

Generate the 256 unsigned 64-bit table words as:

```text
gear[i] = big_endian_u64(SHA256(ASCII("orna.gear.v1") || 00 || octet(i))[0:8])
```

For every byte b from the beginning of a chunk:

```text
h = ((h << 1) + gear[b]) mod 2^64
n = n + 1
if n >= 65536 and ((h & ((1 << 18) - 1)) == 0 or n == 1048576):
    emit the n bytes; h = 0; n = 0
```

**ORNA-OGB-006** Writer policy, chunk bounds and observed deduplication MUST be inspectable. Re-encoding compressed media can change most bytes; no fixed deduplication ratio is guaranteed. Rechunking is a storage-only operation with potentially increased retained Git history, requiring an explicit estimate and the existing rewrite safeguards.

## Repository row profile ORR-2

Portable `encode(..., format: orna)` is unchanged. Only the repository row decoder, with the exact field schema and selected snapshot supplied, additionally recognises the following data record in a Blob-typed slot:

```text
{ blob: "sha256:<64 lowercase hex digits>", length: <nonnegative decimal integer> }
```

It resolves through `.orna/blobs/<2>/<62>/` in that context. Field order in canonical output is `blob`, then `length`; fields are exact with no duplicates/unknown fields. This is not a source expression that constructs a Blob, not a callable `blob()` intrinsic, not arbitrary filesystem access, and not valid portable Blob text decoding. A structural record with these names in a non-Blob field remains ordinary data. Parsing still uses the normal row-unit parser; schema-directed repository admission supplies the special storage interpretation.

**ORNA-OGB-007** ORR-2 MUST also accept legacy inline padded-Base64 strings for Blob fields. Writers SHOULD inline values of at most 64 KiB and MUST externalise larger values; admitted external references may remain external at any size. One field has one value; inline and reference spellings MUST NOT create separate logical identities. A plain portable decoder MUST reject the reference record as a Blob.

Example row body, in a repository providing the matching content root:

```text
{
  title: "An example recording",
  content: {
    blob: "sha256:0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef",
    length: 7340032,
  },
}
```

The digest above illustrates the spelling, not supplied audio. Executable fixtures contain generated descriptors and real matching bytes.

## Repository value profile ROV-2 and semantic substitution SOV-2

ROV-2 is schema-directed OVB-1 with one storage-only alternative in logical Blob slots:

```text
CBOR tag 60100 around [content_sha256_bytes32, total_length_uint]
```

All other representations are unchanged, including UUID/digest structural byte strings: these are not mistaken for logical Blob fields. The snapshot supplies the lookup context. ROV-2 accepts inline OVB byte strings as well. Tag 60100 is forbidden in OVB-1, its nested generic values, `orna.present.v1`, request fingerprints and portable text output. Reading one codec never guesses the other from the bytes.

SOV-2 uses the same structural traversal but replaces EVERY logical Blob leaf, inline or external, with this content commitment. It is an identity-input encoding, not a general decoder. For format-2 row digests:

```text
SHA256(ASCII("orna.row.v2") || 00 ||
       SOV-2([database_id, table_id, canonical_key, canonical_stored_fields]))
```

A trusted imported/inline value already has its computed commitment; a promised persisted value retains its declared commitment and validation state. A forged commitment is corruption, not an accepted logical rewrite. This hash is a candidate identity: exact equality and collision handling still follow the Blob rules. Existing `orna.row.v1` digests remain unchanged for retained format-1 records.

**ORNA-OGB-008** ROV-2 storage references MUST NOT escape as ordinary OVB-1 Blob values. SOV-2 substitution MUST be type-directed, apply recursively to every Blob leaf and leave other byte-bearing nominal values unchanged. Storage representation changes with equal content MUST yield equal SOV-2 row digests.

## Compact profile integration

`compact-storage-v2` retains the Parquet, compression, key ordering, generation, schema projection, bounds and recovery rules from profile 1. Its manifest has `profile: "compact-storage-v2"`. Each segment entry still names its own `profile_version`, either 1 (old segment, unchanged) or 2. Segment encoding MUST be determined from its entry and verified physical metadata, never from the containing manifest alone.

In every profile-2 Parquet file, `orna.profile` is exactly `compact-storage-v2`. `orna.table`, `orna.schema.sha256`, `orna.schema.ovb`, `orna.columns.ovb` and `orna.encoder` retain their profile-1 definitions. Schema and column-descriptor metadata remain OVB-1: storage-only references appear in row payloads, never in the schema. The segment entry's `profile_version` and the file's `orna.profile` must agree. A profile-1 segment retains `orna.profile = compact-storage-v1`, even under a v2 manifest. All hash fields identifying physical files remain hashes of their actual bytes. Row semantic digest selection comes from the repository format, not the segment encoder.

In profile-2 column descriptors, a logical Blob uses `encoding_kind: "blob-ref"`, `parameters: [2]`, and unannotated BYTE_ARRAY containing a complete ROV-2 Blob value. A composite fallback uses `encoding_kind: "rov"`, `parameters: [2]` and its complete schema-directed ROV-2 value. All other mappings remain those of profile 1. Logical content equality/hash is not the lexical ordering of these encoded references; no Blob byte-order statistics are inferred from their digests. The original inline `blob` mapping remains valid in profile-1 segments.

**ORNA-OGB-009** Readers MUST support mixed profile-1/profile-2 segments under the profile-2 manifest, decode each explicitly, and compare cross-profile rows by logical fields. ORR-2/ROV-2 repository field tokens MUST resolve to reachable roots before the snapshot is called complete. Segment-side dependency indexes may accelerate this validation but MUST be derived from validated segment values, never trusted unverified metadata that suppresses a required root.

## Capture and publication durability BLOB-CAPTURE-1

There is still one logical database transaction boundary. This ordering bridges streamed content storage and the local transaction engine; it does not pretend they are a single physical write.

1. Allocate a unique owner-bound import ID and an unexposed quarantine area. Check permission and quotas before reading. Temporary data remains outside ordinary Git's prune namespace while incomplete.
2. Read bounded pieces, compute chunks and raw-content digest, and honour cancellation. Write completed objects into an import pack or equivalent; reserve its durable `.keep` protection before installing it into the shared object database. Flush according to the claimed crash model.
3. Build and validate the complete OGB root. Establish a durable native Git pin ref under `refs/orna-local/blobs/<runtime-id>/<import-id>` naming a synthetic commit whose tree reaches it. Only then release temporary installation protection under the coordinated maintenance lock. Pin commits are local retention roots, not a second database history.
4. In the existing Orna activation transaction, insert/update the row and record its Blob dependency/pin ownership together. Acknowledgement requires both durable bytes and the durable row. Capture on its own returns a protected value; it does not implicitly insert a global File row or commit HEAD.
5. On rollback, retain only references still owned by a live value, another transaction or a retained operation; mark other import roots eligible for coordinated cleanup. A crash may leave reclaimable bytes, never an acknowledged dangling row.
6. Publication PUB-1 includes all Blob roots required by the frozen batch in its private candidate tree, together with rows, source/schema and other metadata. A candidate's native Git closure must precede branch visibility. After ref advancement, normal index/worktree reconciliation and Turso watermark cleanup still run.
7. Release local pins only after proving that the current published graph or remaining local holders retain the content. Recover unfinished pin/journal transitions before admitting writes or running maintenance.

**ORNA-OGB-010** Durable uncommitted rows, retained result values and in-flight publication state MUST protect their content from collection by native Git reachability/protection mechanisms, not only by an OID string in SQLite. Read/write/pin/maintenance races MUST be serialised. Concurrent external destructive prune commands that ignore the documented maintenance boundary are unsupported and MUST NOT be claimed safe.

**ORNA-OGB-011** Publisher recovery MUST cover crashes before object protection, after pinning, before/after row commit, before/after branch CAS and during index reconciliation/pin cleanup. Only the frozen pending prefix is consumed. Later tail writes remain protected. Import/publish failures MUST preserve unrelated user files, partially staged changes and submodule work.

**ORNA-OGB-012** `refs/orna-local/*` MUST NOT be synchronised as required database continuity by Orna clone/push. Required allocator/checkpoint refs under `refs/orna/*` retain their existing rules. A mirror may physically copy extra refs; such copies MUST NOT imply the copied runtime owns live writers.

## Staging, merging and access

**ORNA-OGB-013** Staging a Blob field through Orna MUST stage its required representation closure as the same logical change, without staging unrelated paths. A plain Git commit containing only a reference token but no required native tree is an invalid Orna snapshot. Orna MUST diagnose it, not fetch a different version by filename.

**ORNA-OGB-014** Semantic merge MUST compare Blob contents as indivisible values: equal content coalesces, one-sided replacement follows that side, and divergent replacements conflict. It MUST NOT concatenate or independently merge chunk entries into a recording. Merge/rewrite MUST regenerate and validate the content-root binding for the resolved rows. A Git textual merge succeeding is not database-validity evidence.

**ORNA-OGB-015** A reviewed Git commit action MUST bind the staged tree, symbolic/detached HEAD and candidate schema/content closure at review time and revalidate them at protected publication. A separate check-then-commit wrapper is insufficient. The new `sys.admin.review_commit` and `sys.admin.commit_reviewed` operations implement this boundary without changing the older unguarded signature's meaning.

**ORNA-OGB-016** Partial clones MUST remain complete logical snapshots despite absent local chunks. Sparse checkout MUST NOT be treated as a transfer filter or permission control. Lazy readers MUST preserve offline errors, snapshot context, fetch budgets and public-API metadata; no eager media download is permitted just to list its row. Broad unindexed queries may still need broad data scans.

**ORNA-OGB-017** Complete offline export/verification MUST walk the selected database graph and every required pinned dependency repository, including recursive submodules, with cycles/duplicate visits bounded. A parent clone or ZIP is not proof of dependency completeness. A CWD export must first freeze a consistent recoverable CWD state; it MUST NOT merely copy a live `state.db` and call it a portable commit.

**ORNA-OGB-018** Remote repository access MUST be treated as access to that repository's content. Neither sparse checkout, hidden paths, range URLs nor chunk hashes are authorisation boundaries. An application-only client uses the host's admitted interface, not raw clone credentials for a private knowledge base.

**ORNA-OGB-019** Deleting a row/root from HEAD MUST NOT delete bytes needed by retained ancestry, pins or dependencies. History rewriting, complete purge and retention changes MUST be explicit and recoverable as far as their declared policy permits. Reflogs, mirrors, clones and backups may retain copies; ordinary Git GC cannot promise permanent global erasure.

**ORNA-OGB-020** Git compatibility MUST NOT be presented as unlimited hosting, constant-size clones, arbitrary object-range network support or guaranteed performance. Implementations MUST measure commit/tree/index overhead, batched hydration, seeks, retained history and quotas. Content chunking does not solve unindexed table planning.
