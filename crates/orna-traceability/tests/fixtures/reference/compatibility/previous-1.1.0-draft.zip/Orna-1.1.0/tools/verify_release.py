#!/usr/bin/env python3
"""Verify an extracted release or ZIP without modifying any payload."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,zipfile
R=Path(__file__).resolve().parents[1]
def digest(b):return hashlib.sha256(b).hexdigest()
def check(get,names):
 errors=[]
 def require(c,msg):
  if not c:errors.append(msg)
 manifest=json.loads(get('file-manifest.json'));expected=set(manifest['files']);excluded=set(manifest['self_exclusions'])
 require(names==expected|excluded,'File manifest does not describe the complete payload')
 for p,item in manifest['files'].items():
  safe=PurePosixPath(p);require(not safe.is_absolute() and '..' not in safe.parts and '\\' not in p,'Unsafe path: '+p)
  try:data=get(p)
  except (OSError,KeyError):errors.append('Missing '+p);continue
  require(len(data)==item['size'] and digest(data)==item['sha256'],'Hash/size mismatch: '+p)
 seen=set()
 for line in get('SHA256SUMS').decode().splitlines():
  d,p=line.split('  ',1);require(p not in seen,'Duplicate checksum: '+p);seen.add(p)
  try:require(digest(get(p))==d,'SHA256SUMS mismatch: '+p)
  except (OSError,KeyError):errors.append('Missing checksum file '+p)
 require(seen==names-{'SHA256SUMS'},'Incomplete SHA256SUMS inventory')
 release=json.loads(get('release.json'));require(release['version']=='1.1.0','Wrong version')
 require(release['normative_payload_count']==len(release['normative_payload_sha256']),'Bad normative count')
 for p,d in release['normative_payload_sha256'].items():require(digest(get(p))==d,'Normative digest mismatch: '+p)
 for item in release['publications']:require(digest(get(item['file']))==item['sha256'],'Publication mismatch')
 if errors:raise ValueError('\n'.join(errors))
 print(f'PASS: {len(names)} files; complete sizes/SHA-256, normative inputs and generated publications verified')
def main():
 ap=argparse.ArgumentParser();ap.add_argument('zip',nargs='?',type=Path);a=ap.parse_args()
 try:
  if a.zip:
   with zipfile.ZipFile(a.zip) as z:
    raw=z.namelist();prefix='Orna-1.1.0/'
    if len(raw)!=len(set(raw)) or any(not n.startswith(prefix) for n in raw):raise ValueError('Duplicate/foreign ZIP members')
    if z.testzip():raise ValueError('ZIP CRC failure')
    check(lambda p:z.read(prefix+p),{n[len(prefix):] for n in raw})
  else:
   names={str(p.relative_to(R)) for p in R.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.zip'}}
   check(lambda p:(R/p).read_bytes(),names)
 except (ValueError,OSError,KeyError,zipfile.BadZipFile) as e:print('FAIL:',e);return 1
 return 0
if __name__=='__main__':raise SystemExit(main())
