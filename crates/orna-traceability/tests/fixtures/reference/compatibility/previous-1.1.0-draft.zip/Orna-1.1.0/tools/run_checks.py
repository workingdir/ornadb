#!/usr/bin/env python3
"""Execute scoped publication checks and preserve full local outputs."""
from pathlib import Path
import hashlib,importlib.metadata,json,os,platform,subprocess,sys
R=Path(__file__).resolve().parents[1]
TESTS=[
 ('media-fixtures','make_media_fixtures.py','Generated original bytes/metadata, not Orna decoding'),
 ('syntax','syntax_probe.py','Bounded EBNF syntax expectations; no type/effect/runtime proof'),
 ('blob-model','test_blob_model.py','Selected Python Blob/storage invariants; not production memory/crash proof'),
 ('native-git','git_blob_proof.py','Isolated real Git transport/object experiments; not Orna execution'),
 ('float-vectors','check_float_vectors.py','Selected retained numeric vectors'),
 ('path-vectors','check_path_vectors.py','Selected retained path/collision vectors'),
 ('protocol-model','protocol_model.py','Selected structural/state models; not authenticated clients/servers'),
 ('static','validate.py','Publication/source/API/profile consistency only'),
]
def main():
 (R/'evidence').mkdir(exist_ok=True);entries=[]
 env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
 for name,script,scope in TESTS:
  cmd=[sys.executable,'tools/'+script]
  try:
   p=subprocess.run(cmd,cwd=R,env=env,capture_output=True,text=True,timeout=180)
   output=p.stdout+p.stderr;rc=p.returncode
  except subprocess.TimeoutExpired as e:output='Explicit check timeout; not a pass.\n';rc=124
  path='evidence/'+name+'.log';(R/path).write_text(output)
  entries.append({'name':name,'command':'python tools/'+script,'exit_code':rc,'passed':rc==0,'scope':scope,'log':path,'script_sha256':hashlib.sha256((R/'tools'/script).read_bytes()).hexdigest()})
  print(('PASS' if rc==0 else 'FAIL')+': '+name)
 versions={'python':platform.python_version(),'git':subprocess.check_output(['git','--version'],text=True).strip(),'pandoc':subprocess.check_output(['pandoc','--version'],text=True).splitlines()[0],'authoring_dependencies':{p:importlib.metadata.version(p) for p in ['lark','jsonschema','beautifulsoup4']}}
 report={'specification':'1.1.0','scope':'Source publication and selected reference checks only','engine_execution':'not-executed','all_passed':all(x['passed'] for x in entries),'check_groups':len(entries),'tool_versions':versions,'results':entries}
 (R/'evidence/checks.json').write_text(json.dumps(report,indent=2)+'\n')
 return 0 if report['all_passed'] else 1
if __name__=='__main__':raise SystemExit(main())
