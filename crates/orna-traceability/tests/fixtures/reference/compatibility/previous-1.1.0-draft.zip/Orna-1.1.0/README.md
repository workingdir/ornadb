# Orna 1.1.0

**Language, runtime and repository specification — source edition.**

Conceptual integrity is the governing principle: an executable Git database whose typed records can contain immutable Blob values; source, schema, data, binary content and pinned dependencies select one coherent revision. Large content is represented using ordinary Git objects and loaded on demand. No LFS or second content history is required.

## Start here

[Combined HTML](index.html) · [Combined Markdown](Orna-1.1.0.md) · [What changed](CHANGELOG.md) · [Migration](MIGRATION.md) · [Implementation goal](implementation/ORCHESTRATOR.md)

The complete specification is the ordered chapters in `source/manifest.json`, `api/sys.json`, `grammar/orna.ebnf` and the profiles. The combined publications are generated from those sources. `release.json` identifies the normative payload digests. New chapters cover Blob values, native Git representation, ingestion/inspection, minimal source-hosted applications and compatibility. Unchanged 1.0 facilities and tests remain; a minimal first milestone does not delete their requirements.

## Give this to the implementation orchestrator

Extract this directory to `reference/Orna-1.1.0/` in the implementation checkout. Read the implementation goal, then use it as the active goal's full objective. Reuse the user's existing OMP configuration and issue state. Root model: `openai-codex/gpt-5.6-terra`. Every descendant: `openai-codex/gpt-5.6-luna`, with maximum descendant depth 3 and no model substitution.

The first deliverable is a real table with a `content: Blob` field: import, inspect, retrieve/play, update metadata, revisit a revision, and reopen a complete copy offline. Keep the first UI to table list, input, Run, result and explicit refresh. Advanced watches, saved-query stores and styling frameworks are not prerequisites.

## Reproduce publication checks

Python 3.11+, Git, Pandoc and the pinned authoring dependencies in `tools/requirements.txt` are required. No network services or model credentials are used by the reference checks.

```sh
python tools/build_publication.py
python tools/run_checks.py
python tools/package_release.py
python tools/verify_release.py
```

The Python Blob model and local real-Git partial-clone experiment are reference evidence only. Orna syntax probes do not check types or execute code. Detailed commands/results and remaining implementation obligations are in `evidence/VALIDATION.md` and `evidence/checks.json`. No production Orna engine, crash-fault campaign, browser or independent Parquet implementation has been executed by these publication tools.

This ZIP is the 1.1.0 source/reference release, not a database binary or a generated UI mock. No PDF is included; obsolete 1.0 PDFs and rendered evidence are not relabelled as new results. The exact parent-archive hash and all source changes are recorded in `provenance/`.
