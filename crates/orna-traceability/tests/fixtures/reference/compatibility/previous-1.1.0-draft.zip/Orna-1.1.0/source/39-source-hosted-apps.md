# 34. Source-hosted applications and minimal devtools {#source-apps}

## Conceptual integrity and delivery scope

Orna's application model is functions over typed values and explicit operations. The Git browser, console, table inspector, stylesheet viewer and media player are consumers of that same model. Their application-specific behaviours MUST NOT become hidden engine routes or a separate JavaScript implementation of the language.

**ORNA-APP-001** The default devtools and playground MUST be one optional ordinary application. Its first usable surface MUST provide a table list, a bounded structural inspector, one multiline Orna input, an explicit Run operation, and explicit refresh. Watches, saved snippets, reactive stores, a rich IDE, theme systems and visual query builders MUST NOT be prerequisites for this milestone. Retained 1.0 live/REPL requirements are not deleted; this milestone is not a full-server conformance claim.

**ORNA-APP-002** Browse and console output MUST use the same typed inspection semantics. Selecting a table or loading source into the console MUST NOT perform mutations. Run MUST execute through the real admitted Orna evaluator; no demo parser or canned response is an implementation. Clear output MUST NOT clear bindings or data, and resetting bindings MUST NOT reset the database.

**ORNA-APP-003** The default stylesheet SHOULD be absent or a small ordinary optional stylesheet. Native semantic HTML and form controls MUST remain usable without it. Portable UI meanings MUST NOT depend on CSS, HTML tag names, a DOM or a browser. Web styling belongs to the selected web renderer/application package, not intrinsic Blob or table types.

## Source and resource ownership

The standard library remains optional and explicitly pinned. A Git submodule is a supported, useful dependency representation; this release does not replace it with an implicit package manager. The default editable devtools application may be copied from a pinned distribution template into the user's own `devtools/` module tree while using the pinned `std` dependency. This avoids pretending that edits inside a read-only pinned submodule are automatically recorded in the parent.

**ORNA-APP-004** Selected source MUST be the actual executed source. A default UI MAY be vendored as ordinary source/resources or used from a pinned dependency. Its origin, selected revision and ownership MUST be visible. Removing its import/mount MUST NOT trigger a hidden built-in fallback or automatic reinstallation. Git/local database operation MUST remain usable when devtools is absent or broken.

**ORNA-APP-005** Editing a submodule dependency MUST follow ordinary Git semantics: commit changes in the dependency, then update the parent gitlink. Alternatively a user may explicitly vendor/fork the source into a local module. No silent mutable overlay over a pinned dependency or duplicate `std` namespace is permitted. Updates MUST preserve local work, expose conflicts and retain exact provenance.

**ORNA-APP-006** CSS, required browser adapter code, Wasm modules, images and other package resources MUST be ordinary snapshot-owned content. They MAY be raw tracked files read through `sys.blob.resource`, or Blob fields in an application-owned table. A reusable `std.web` response consumes Blob content plus ordinary media-type metadata; it MUST NOT know about `std.devtools.Asset` or a special playground directory.

**ORNA-APP-007** `sys.blob.resource(path)` MUST resolve against the caller module's selected package root and captured source snapshot, with a safe slash-separated relative path and no symlink/traversal escape. In CWD the resource bytes are captured in the same coherent generation as that code before use. In committed execution they are exact Git objects. A branch name, current host file, arbitrary URL or newest installed library MUST NOT be substituted. Access through this function does not expose the whole repository over HTTP.

**ORNA-APP-008** A package build MUST record all resource dependencies in its source/dependency closure and reject unresolved dynamic resource requirements before claiming an offline-complete artifact. Host bindings and generated outputs MUST carry their source/toolchain/interface identity. The HTML, client module and bootstrap contract MUST be selected as one coherent build, never mixed by mutable asset URLs.

Illustrative ordinary database layout:

```text
library/
    main.orna
    music.orna
    music/Song/...
    devtools/main.orna
    devtools/browse.orna
    devtools/console.orna
    devtools/style.css             # optional
    stdlib/std/                   # pinned Git submodule, when selected
    .gitmodules
    .orna/format.orna
    .orna/database.orna
    .orna/blobs/                  # managed native Git trees, usually sparse
    .git/orna/                    # private local state/cache, never committed
```

## Serving as ordinary Orna behaviour

**ORNA-APP-009** A source-hosted application implementation MUST place route selection, HTML generation, reusable asset responses and application session orchestration in replaceable `.orna` library code. The engine MAY supply typed socket/platform operations, the admitted evaluator and atomic repository/transaction primitives. A library wrapper around a native complete devtools/server implementation does not satisfy this boundary.

**ORNA-APP-010** `orna serve` MUST select an explicit serving entry and supervise it separately from root `main()` and unrelated streams. Until a package supplies that entry, the host MUST diagnose its absence instead of guessing source or installing a UI. Default loopback and trusted-perimeter rules remain unchanged. A source-hosted serving profile MUST retain the exact existing live endpoints when claiming the full Server class.

**ORNA-APP-011** The HTTP/application service lifetime MUST NOT be one open database transaction. Each explicit mutation uses the existing short/optimistic activation and request boundary; long listener/client waits are supervised service state. The host's durability/cancellation/identity invariants MUST NOT be duplicated in private application tables.

The library-facing signatures are versioned in the selected package, not added to the source grammar. This release specifies their behaviour and proof obligations, not an invented already-implemented `ui.Form` API. The reference code examples do not claim a new UI framework exists.

## Minimal browser operation and content delivery

**ORNA-APP-012** A first source-hosted web UI MAY use ordinary request/response HTML and native forms without a Wasm client. Requests MUST carry normal perimeter/session/CSRF protection, bounded source/input, and a stable mutation request identity where recovery is offered. A failed or lost response MUST NOT cause automatic replay of a mutating form. This mode is not advertised as `orna.present.v1` without that protocol's full behaviour.

**ORNA-APP-013** A renderer MUST inspect Blob metadata without loading the media. An explicit download/preview MUST resolve a typed row/content reference in an admitted snapshot and check authority on each request. Raw digest knowledge or a filename is not a bearer capability. MIME handling, escaping, `nosniff` and non-execution of inspected source/HTML MUST preserve the trust boundary.

**ORNA-APP-014** A web media response SHOULD implement RFC 9110 single-byte ranges, HEAD and conditional requests against immutable content identity. Invalid/unsatisfiable ranges MUST return the applicable error, not wrong bytes. Range reads MUST use the shared Blob reader. A later stream failure terminates the response; it MUST NOT be reported as a successfully verified complete body. No base64 media payload belongs in a presentation delta merely to start playback.

## Optional Orna-authored browser runtime

**ORNA-APP-015** When the Orna-authored browser-client profile is implemented, protocol processing, generic control behaviour and rendering MUST execute from selected `.orna` code. Compiling the existing admitted evaluator to Wasm and loading these modules is the initial implementation route; an equivalent direct compiler is permitted later. Generated JavaScript may bind platform calls but MUST NOT reimplement Orna semantics or contain app-specific Git/table logic.

**ORNA-APP-016** Browser modules MUST link only granted browser interfaces and shared pure functionality. Server database/Git handles and captured server closures MUST NOT cross to the browser as operational values. Explicit programming uses `eval`/`watch`; normal page interactions use typed action handles. No new unnegotiated fields or Blob-reference tags may be added to `orna.present.v1`.

**ORNA-APP-017** Application state transitions MUST pass the current immutable model explicitly. A persistent REPL binding or captured closure MUST NOT be reinterpreted as a mutable reactive cell. The default console environment MUST be isolated from the page's code/bindings even when both share one database context.

**ORNA-APP-018** Draft typing, caret, focus, scrolling and native control feedback MUST remain local and responsive. Incoming results MUST NOT overwrite newer unsent edits. A control implementation must distinguish the submission it acknowledges from edits made afterward. Animation, signal frameworks and a WPF-style object system are not required to satisfy this rule.

**ORNA-APP-019** Connection resumption, durable request recovery and serialisable page-state restoration MUST remain separate claims. An expired session yields a new session, not a replayed transcript. New runtime generations invalidate operational handles. Background work that survives page lifetime requires explicit independent ownership. No restore operation may repeat an uncertain external or Git mutation under a fresh ID.

**ORNA-APP-020** Updating devtools/renderer/server source MUST validate a coherent candidate before switching new sessions to it. Existing sessions either retain their admitted version until a bounded drain or explicitly reload with new handles. Invalid source MUST leave local core recovery available. A stale button MUST NOT acquire a new implementation meaning.

## Acceptance, not bespoke infrastructure

**ORNA-APP-021** A source-hosted/replaceable-framework claim MUST be demonstrated with a second ordinary application and a minimal replacement response renderer or HTTP composition written in `.orna`, using only published interfaces and without native route edits or app-specific JavaScript. A mock page, a CSS editor, or a native shim named `std.web` does not establish this claim.

**ORNA-APP-022** The first product demonstration MUST import a photo and a recording, inspect/query their rows, view/play or retrieve their exact content, change a metadata field, inspect history, and reopen a complete copy offline. It MUST show actual storage/evaluator behaviour and measured hydration, not a simulated browser-only dataset.
