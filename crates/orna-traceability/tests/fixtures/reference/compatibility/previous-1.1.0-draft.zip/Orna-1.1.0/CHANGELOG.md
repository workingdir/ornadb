# Orna 1.1.0 — 2026-10-04

## Retained

Git is the published executable database. Source/schema/records/dependency pins and immutable content belong to its snapshots. Partial clone and sparse checkout remain distinct. Embedded Turso/SQLite owns unpublished CWD. Ordinary primary keys, immutable value capture, OVB-1, canonical portable text and `orna.present.v1` remain.

## Added

- One immutable Blob model independent of filenames, rows and physical chunk layout; explicit bounded access and owner-scoped capture operations.
- Native Git-reachable OGB-1 content trees, a defined streaming chunker, range traversal, pinning, publication/GC/recovery rules and complete dependency-aware portability.
- Explicit repository format 2, ORR-2/ROV-2 stored Blob references, SOV-2 row identity and mixed-version compact storage. No silently overloaded wire byte strings.
- Ordinary ingestion, file/resource distinctions, bounded metadata interpretation and provenance requirements for explicit analysis.
- Minimal source-hosted devtools, reusable renderer resources, editable/removable app source, retained submodule semantics and optional Orna-authored browser-client obligations.
- Guarded reviewed-commit operations and a staged implementation/upgrade goal.

## Corrected

The two valid failure-administration fixtures now supply their already-required `expected_version`. The original archive and its checksums are not modified. This is a test-input correction, not weakened CAS behaviour.

## Publication scope

This edition contains complete source, combined Markdown/HTML, full API, profiles, grammar, retained and new conformance inputs, executable reference checks, migration instructions and a handoff goal. The 1.0 PDFs/screenshots and nested historical archives are intentionally not republished as 1.1 artifacts. The supplied parent ZIP is identified by SHA-256 in provenance. No production engine execution, browser-Wasm implementation or full conformance is claimed by publication.

The inherited `MIGRATE-SURFACE-091` oracle no longer links to nonexistent `ORNA-MIGRATE-001`. Existing migration requirements remain. Broken inherited publication anchors are repaired; no new language behaviour follows from an anchor/index repair.
