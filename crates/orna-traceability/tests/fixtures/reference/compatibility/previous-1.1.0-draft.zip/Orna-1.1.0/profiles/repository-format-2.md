# Repository format 2

The exact marker, row/value/digest profiles and mixed-segment rules are defined in [Git-native storage](../index.html#blob-storage). Migration is [UPGRADE-2](../index.html#upgrade). Old format-1 commits remain immutable and readable by their own profile.
