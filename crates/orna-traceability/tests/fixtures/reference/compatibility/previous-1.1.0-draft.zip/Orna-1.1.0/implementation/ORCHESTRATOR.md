# Orna 1.1.0 implementation goal

Read `reference/Orna-1.1.0/README.md`, `release.json`, the source chapters in `source/manifest.json`, and this goal before changing implementation. The supplied 1.1.0 source, API, profiles, grammar and conformance oracles are the source of truth. `MIGRATION.md` is implementation guidance; examples are not substitutes for the normative contracts.

## Governing principle: conceptual integrity

Preserve an executable, versioned Git database: source, schema, records, content and pinned dependencies select one coherent snapshot. Blob is the one immutable byte-value primitive. Its content identity is independent of chunk layout. Tables retain their ordinary keys. Do not replace Git, introduce LFS/a second media store, create a compulsory File/Asset registry, or discard current runtime/partial-clone work. `std` submodules remain supported. Conceptual integrity is fewer consistent mechanisms, not renaming private native machinery as library code.

## Models and ownership

The root orchestrator is exactly `openai-codex/gpt-5.6-terra`. Every descendant, reviewer and nested specialist is exactly `openai-codex/gpt-5.6-luna`. No model fallback is allowed. Root depth is zero; at most three descendant levels. Verify the installed OMP settings and actual model selection before delegation. Do not invent configuration keys; reuse the user's working harness. If a mandatory model is unavailable, checkpoint and stop rather than switch models.

Use domain-specific owners. Reuse existing work/issue tracking, code and evidence. Inspect the current checkout and its uncommitted work; no stale commit hash in a previous chat is a migration base. Determine actual dependency and call graphs, not just crate names. Give each worker bounded requirements, owned paths, acceptance commands and dependencies. One writer owns shared runtime files, API registries, manifests and lockfiles at a time. Use isolated patches/workspaces only where the installed harness supports them. Nested workers inherit all restrictions; no spawning a second independent root through a shell.

Recommended concurrent domains are (1) Blob/evaluator/codec, (2) native Git representation/partial clone, (3) capture/transaction/publication recovery, (4) ordinary ingestion/metadata, (5) minimal devtools/resources, and (6) independent conformance/migration review. Start with four implementation workers plus a reviewer; increase only when file ownership and runtime capacity justify it. Do not manufacture 30 parallel tasks in the same giant file.

## First deliverable: a usable thin path

Get a real format-2 database working with a `Song(id: Str)` table and `content: Blob`. Import a real/synthetic recording and image, query rows through the production REPL, display a metadata summary without fetching the payload, read a range, retrieve exact bytes, modify a title, and open history. A small table list + input + Run + result + explicit refresh is enough. No Watch UI, saved-query store, theme engine, React rewrite or new grammar is necessary. No simulated browser console may stand in for real execution.

Use an ordinary source-hosted response renderer to expose the image/audio or a reliable download. Preserve the working 1.0 live stack while moving app-specific routes/resources into Orna; do not rewrite it in parallel. Reuse the actual parser/type checker/evaluator, not test-harness stubs. The later Orna-authored Wasm client is a separate claimed profile, not a blocker to the first usable path and not permission for permanent app logic in JS.

## Completion sequence

1. Inventory current capability/format readers and tests. Establish the byte-identity vs storage-identity contract, owner-bound Blob values and explicit API/profile versions. Update hardcoded 1.0 payload/requirement counts to derive from the actual release inventory; do not disable integrity checking.
2. Implement shared lazy Blob representation, bounded operations and snapshot pins end to end. Audit every `Vec<u8>`, codec, row hash, equality path, table rewrite and result inspector for accidental materialisation. Preserve all OVB-1 bytes and request/consumer identity algorithms; implement the separate ROV-2/SOV-2 context.
3. Implement OGB-1 native trees/chunks, range traversal and batching. Prove native reachability with ordinary Git, payload-free clone/list, changed-layout same-content identity, invalid graph rejection and offline errors. Keep submodule/dependency closure explicit.
4. Integrate streamed acquisition, pack protection/local pins, row commit, PUB-1 reconciliation and recovery. Run crash fault points through production code, including aggressive sequential GC and competing writes/maintenance under the declared boundary. Never silently consume an unprotected pending tail.
5. Implement mixed-profile upgrade and guarded reviewed commit. Preserve old commits, allocator continuity, ordinary index/worktree changes and user submodule edits. Add no destructive migration shortcut or metadata-only fake downgrade.
6. Deliver the first devtools path and inspectable source/resources. Add common bounded file inspection as library behaviour, not another persistent catalogue. Remote analysis remains explicit and may be outside this milestone; no costly automatic model call.
7. Complete applicable retained 1.0 and added 1.1 tests. Report full engine, model, syntax, browser, Parquet, performance and unavailable-environment results separately. Expand source-hosted/optional client profiles only against their explicit acceptance criteria.

## Evidence and goal-loop discipline

The goal is implementation, not repeated design documents. Every task returns changed files, implementation entry points, commands/results, scope and remaining defects. Independently review integration before marking done. A completed batch or successful helper model does not complete the goal. Failed checks become specific tasks; repeated failures require a changed approach, not another identical retry. Preserve minimal durable next actions and ownership before compaction or cancellation.

Use real current-revision tests. Do not alter the spec or golden vectors to pass a broken implementation. The two inherited failure-admin fixture corrections are already specified in 1.1; retain expected-version enforcement. A genuine new contradiction is a tracked specification defect with a reproducer, not permission for a quiet fork.

Do not discard user changes, push/force-push, purge history, change global model configuration, install unknown plugins, run uncontrolled media imports or disclose private files. Work within existing explicit permissions. Honour configured time/token/storage limits; exhaustion is not completion. Leave unresolved mandatory work open, with exact recovery state and next steps. Never label syntax checks or a Python Git model as production Orna execution.
