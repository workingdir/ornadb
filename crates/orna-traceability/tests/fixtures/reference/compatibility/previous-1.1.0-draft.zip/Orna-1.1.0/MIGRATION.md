# Moving the implementation from 1.0.0 to 1.1.0

This is a specification update, not an engine migration utility. Start with `source/40-upgrade-contract.md` and its profile table. The new repository format is 2; it deliberately does not silently reinterpret format-1 bytes. The portable value and live protocol coordinates stay OVB-1 and `orna.present.v1`.

Retain Git, root reachability, standard-library submodules, the admitted evaluator, embedded runtime, publication journal, checkpoint/allocator continuity, row/compact readers and partial-clone machinery. Extend these owners; do not start a replacement database. Reconcile the current checkout before using any old audit snapshot.

The new call surface is listed completely in `api/sys.json` and summarized in `api/additions-1.1.json`. The critical integration is a lazy internal Blob carrier that still materialises exact bytes only at explicit bounded codecs/read boundaries. Adding Git chunks without fixing row hashing/encoding still fails the requirement.

Implement both descriptor closure and real Git tree entries. Stage root dependencies with each affected row, protect unpublished content with native roots, and couple acknowledged rows to durable content. Range addressing is inside OGB-1; Git still transfers whole chunk objects. No detached external content server is required.

A controlled upgrade makes a new format-2 commit and leaves old history untouched. Existing inline values/format-1 compact segments can remain readable without immediately rewriting the entire database. Cross-profile equality is logical, not raw digest equality. A downgrade after format-2 values exist requires lossless conversion and validation, not replacing the marker.

For optional UI work, implement one default devtools application: table browser + shared value inspector + multiline Run + explicit refresh. Package CSS/JS are ordinary snapshot resources; binary fields are Blob. Devtools is removable and not a storage primitive. Preserve `std` as a submodule when selected; edits to its code follow normal submodule commit/gitlink rules. The optional browser runtime can reuse the existing evaluator compiled to Wasm; it must not become a second independently implemented Orna language.

Use `implementation/ORCHESTRATOR.md` as the goal. Run `python tools/run_checks.py` to validate the specification bundle, then implement/run the corresponding engine tests. A passing bundle check does not mean migration code exists or passed.
