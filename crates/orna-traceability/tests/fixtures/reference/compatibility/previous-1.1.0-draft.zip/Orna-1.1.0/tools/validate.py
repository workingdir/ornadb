#!/usr/bin/env python3
"""Read-only source/API/profile/fixture/publication integrity checks."""
from pathlib import Path
from urllib.parse import unquote,urlsplit
import hashlib,json,re,sys
from collections import Counter
from bs4 import BeautifulSoup
from jsonschema import Draft202012Validator
R=Path(__file__).resolve().parents[1]
def load(p):return json.loads((R/p).read_text())
def main():
    checks=[];errors=[]
    def check(name,condition,detail=''):
        checks.append({'name':name,'passed':bool(condition),'detail':detail})
        if not condition:errors.append(name+': '+str(detail))
    jsons=list(R.rglob('*.json'))
    for p in jsons:
        try:json.loads(p.read_text())
        except Exception as e:errors.append(f'JSON {p.relative_to(R)}: {e}')
    check('all-json-documents',not errors,f'{len(jsons)} files')
    manifest=load('source/manifest.json');req=load('tests/requirements.json');ids={x['id'] for x in req}
    check('unique-requirements',len(ids)==len(req),len(req))
    actual=[]
    for c in manifest:
        p=R/c['file'];check('chapter-'+c['id'],p.is_file(),c['file'])
        text=p.read_text();check('chapter-anchor-'+c['id'],'{#'+c['id']+'}' in text)
        for n,line in enumerate(text.splitlines(),1):
            m=re.match(r'\*\*(ORNA-[A-Z0-9-]+)\*\*\s+(.+)',line)
            if m:actual.append({'id':m[1],'chapter':c['id'],'source':c['file'],'line':n,'text':m[2]})
    check('requirements-exactly-match-source',actual==req)
    parent=load('provenance/parent-contract.json');old=set(parent['requirement_ids']);check('all-parent-requirement-ids-retained',old<=ids,sorted(old-ids))
    check('expected-requirement-count',len(req)==954,f'{len(old)} retained; {len(ids-old)} added')
    for p,digest in parent['unchanged_files'].items():check('unchanged-'+p,hashlib.sha256((R/p).read_bytes()).hexdigest()==digest)
    api=load('api/sys.json');delta=load('api/additions-1.1.json');fn={f['name']:f for f in api['functions']}
    check('api-version',api['language_version']=='1.1.0' and api['sys_version']=='1.1')
    for bucket,count in api['counts'].items():check('api-count-'+bucket,len(api[bucket])==count,count)
    check('api-unique-functions',len(fn)==len(api['functions']))
    check('legacy-function-signatures-unchanged',all(fn.get(f['name'],{}).get('signature')==f['signature'] for f in parent['functions']))
    check('new-function-delta-exact',all(fn.get(f['name'])==f for f in delta['functions']))
    check('fourteen-additive-functions',len(api['functions'])-len(parent['functions'])==14)
    # Closure of newly declared sys type names against the public inventory.
    known=set(api['opaque_identifiers'])|set(fn)
    for bucket in ['singletons','reference_aliases','value_types','enums','relations']:
        val=api[bucket]
        if isinstance(val,dict):known.update(val)
        else:known.update(x['name'] for x in val if isinstance(x,dict))
    refs={x for f in delta['functions'] for x in re.findall(r'\bsys(?:\.[A-Za-z_][A-Za-z0-9_]*)+',f['signature'])}
    check('new-api-reference-closure',refs<=known,sorted(refs-known))
    for p in (R/'profiles').glob('*.schema.json'):
        try:Draft202012Validator.check_schema(json.loads(p.read_text()));good=True
        except Exception as e:good=False
        check('json-schema-'+p.name,good)
    d=Draft202012Validator(load('profiles/blob-descriptor.schema.json'))
    check('blob-diagnostic-projection-valid',d.is_valid({'version':1,'sha256':'0'*64,'length':0,'data_tree_oid':'1'*40}))
    check('blob-diagnostic-projection-closed',not d.is_valid({'version':1,'sha256':'0'*64,'length':0,'data_tree_oid':'1'*40,'extra':True}))
    sc=load('tests/scenarios.json');scids=[s['id'] for s in sc['scenarios']]
    check('scenario-count-and-uniqueness',sc['count']==len(scids)==len(set(scids)),len(scids))
    bad={r for s in sc['scenarios'] for r in s['requirements'] if r not in ids};check('scenario-requirement-closure',not bad,sorted(bad))
    new=load('tests/blob-scenarios.json');covered={r for s in new['scenarios'] for r in s['requirements']}
    check('all-new-obligations-have-scenario-oracle',ids-old<=covered,sorted(ids-old-covered))
    ev=load('tests/requirement-evidence.json')['requirements'];check('evidence-honesty',len(ev)==len(req) and all(e['implementation_result']=='not-executed' and not e['full_implementation_coverage_claimed'] for e in ev))
    fm=load('tests/conformance-manifest.json');counts=Counter(f['kind'] for f in fm['fixtures'])
    check('fixture-counts',all(fm['counts'].get(k)==v for k,v in counts.items()) and fm['counts']['total']==len(fm['fixtures']),dict(counts))
    missing=[f['path'] for f in fm['fixtures'] if not (R/f['path']).exists()];check('fixture-paths-exist',not missing,missing)
    for f in load('tests/media-fixtures.json')['fixtures']:
        data=(R/f['path']).read_bytes();check('media-identity-'+Path(f['path']).name,len(data)==f['length'] and hashlib.sha256(data).hexdigest()==f['sha256'])
    for p in ['examples/valid/failure-natural-key.orna','examples/valid/stream-admin-repl.orna']:
        check('reviewed-fixture-correction-'+p,'expected_version: failure.version' in (R/p).read_text())
    # Actual generated HTML is checked, not only the Markdown's declared anchors.
    html=BeautifulSoup((R/'index.html').read_text(),'html.parser');anchorlist=[x['id'] for x in html.find_all(id=True)];anchors=set(anchorlist)
    check('html-unique-anchor-ids',len(anchors)==len(anchorlist))
    invalid=[]
    for node in html.find_all(['a','link','img','script']):
        v=node.get('href') or node.get('src')
        if not v:continue
        u=urlsplit(v)
        if u.scheme or u.netloc:continue
        if not u.path:
            if u.fragment and unquote(u.fragment) not in anchors:invalid.append(v)
        elif not (R/unquote(u.path)).exists():invalid.append(v)
    check('html-internal-links',not invalid,sorted(set(invalid)))
    # Python compilation is a tooling check, not a language implementation test.
    for p in (R/'tools').glob('*.py'):
        try:compile(p.read_text(),str(p),'exec');ok=True
        except SyntaxError:ok=False
        check('python-syntax-'+p.name,ok)
    report={'scope':'Publication/static consistency only; no Orna execution, crash test, browser runtime or independent Parquet conformance','passed':not errors,'checks':len(checks),'results':checks,'errors':errors}
    print(json.dumps(report,indent=2))
    return 0 if not errors else 1
if __name__=='__main__':raise SystemExit(main())
