# Git-native Blob profile

The complete normative definition is [Git-native storage](../index.html#blob-storage), with limits in `blob-storage.json`. This profile is not LFS or the bup format. `blob-descriptor.schema.json` describes an inspection projection, not an alternative binary format.
