#!/usr/bin/env python3
"""Executed authoring/model checks; none executes an Orna engine."""
from pathlib import Path
import hashlib,json,unittest
from blob_model import *
R=Path(__file__).resolve().parents[1]

class BlobTests(unittest.TestCase):
    def test_empty(self):
        s=MemoryStore();b=build(s,[])
        self.assertEqual(b.digest,hashlib.sha256(b'').hexdigest());self.assertEqual(read_range(s,b.root,0,10),b'');verify(s,b.root)
    def test_identity_not_layout(self):
        data=deterministic_bytes(300000);s=MemoryStore()
        a=build(s,fixed_chunks(data,65536));b=build(s,fixed_chunks(data,131072))
        self.assertEqual((a.length,a.digest),(b.length,b.digest));self.assertNotEqual(a.root,b.root)
        self.assertEqual(encode(stored_reference(a.digest,a.length)),encode(stored_reference(b.digest,b.length)))
    def test_range_edges(self):
        data=deterministic_bytes(300000);s=MemoryStore();b=build(s,fixed_chunks(data,65536))
        for start,n in [(0,1),(65530,100),(300000,100),(299999,500),(0,0)]:self.assertEqual(read_range(s,b.root,start,n),data[start:start+n])
        for start,n in [(-1,0),(300001,0),(0,-1),(0,MAX_READ+1)]:
            with self.assertRaises(BlobError):read_range(s,b.root,start,n)
    def test_only_overlapping_chunks(self):
        data=deterministic_bytes(500000);s=MemoryStore();b=build(s,fixed_chunks(data,65536));s.reads=[]
        self.assertEqual(read_range(s,b.root,65530,20),data[65530:65550])
        fetched=set(s.reads)&{oid for oid,_ in b.chunks};self.assertEqual(fetched,{b.chunks[0][0],b.chunks[1][0]})
    def test_metadata_does_not_read_chunks(self):
        s=MemoryStore();b=build(s,fixed_chunks(deterministic_bytes(300000),65536));s.reads=[]
        metadata(s,b.root);self.assertFalse(set(s.reads)&{oid for oid,_ in b.chunks})
    def test_257_chunks(self):
        data=deterministic_bytes(257*1024);s=MemoryStore();b=build(s,fixed_chunks(data,1024));_,n,oid=metadata(s,b.root)
        self.assertEqual(node(s,oid)[0],1);self.assertEqual(verify(s,b.root),b.digest)
        self.assertEqual(read_range(s,b.root,256*1024-5,20),data[256*1024-5:256*1024+15])
    def test_sha256_git(self):
        data=b'hello\x00world';s=MemoryStore('sha256');b=build(s,[data]);self.assertEqual(len(b.root),64);verify(s,b.root)
    def test_missing_chunk_is_not_empty(self):
        s=MemoryStore();b=build(s,[b'abc']);s.objects.pop(b.chunks[0][0])
        with self.assertRaises(BlobError):read_range(s,b.root,0,3)
        self.assertEqual(metadata(s,b.root)[1],3)
    def test_corrupt_git_object(self):
        s=MemoryStore();b=build(s,[b'abc']);s.objects[b.chunks[0][0]]=('blob',b'xyz')
        with self.assertRaises(BlobError):read_range(s,b.root,0,3)
    def test_wrong_meta_digest_detected_by_full_verifier(self):
        s=MemoryStore();b=build(s,[b'abc']);t=_tree_for_test(s,b.root);m=decode(s.objects[t['meta'][1]][1]);m[1]=b'\x00'*32
        t['meta']=('blob',s.put('blob',encode(m)));root=s.tree(t)
        # A successful partial range is intentionally not a whole-digest proof.
        self.assertEqual(read_range(s,root,0,1),b'a')
        with self.assertRaises(BlobError):verify(s,root)
    def test_reject_metadata_aliases(self):
        for data in [b'\x18\x01',b'\x9f\xff',encode([1])+b'\0',b'\xa0',b'\xd9\xea\xc4\x80']:
            with self.assertRaises(BlobError):decode(data)
    def test_storage_reference_not_wire_blob(self):
        raw=encode(stored_reference(hashlib.sha256(b'abc').hexdigest(),3))
        with self.assertRaises(BlobError):portable_blob_decode(raw)
        self.assertEqual(portable_blob_decode(encode(b'abc')),b'abc')
    def test_content_defined_reuse(self):
        data=deterministic_bytes(2<<20);changed=data[:800000]+b'inserted-content'*50+data[800000:]
        a=list(gear_chunks([data]));b=list(gear_chunks([changed]));aids={hashlib.sha256(x).digest() for x in a}
        reused=sum(len(x) for x in b if hashlib.sha256(x).digest() in aids)
        self.assertGreater(reused,len(data)//2)
    def test_chunking_independent_of_read_buffer(self):
        data=deterministic_bytes(1<<20)
        self.assertEqual(list(gear_chunks([data])),list(gear_chunks(fixed_chunks(data,777))))
    def test_metadata_update_reuses_commitment(self):
        digest=hashlib.sha256(b'song').hexdigest();ref=stored_reference(digest,4)
        a=hashlib.sha256(b'orna.row.v2\0'+encode(['title A',ref])).digest()
        b=hashlib.sha256(b'orna.row.v2\0'+encode(['title B',ref])).digest()
        self.assertNotEqual(a,b);self.assertEqual(ref,stored_reference(digest,4))

def _tree_for_test(s,oid):return parse_tree(s.objects[oid][1],s.algorithm)

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(BlobTests))
    report={'scope':'Python model of selected OGB-1 invariants, not Orna execution or a production memory benchmark','tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'passed':result.wasSuccessful()}
    (R/'evidence/blob-model.json').write_text(json.dumps(report,indent=2)+'\n')
    # Known answers are generated independently of native Git plumbing.
    vector=[]
    for label,data in [('empty',b''),('abc',b'abc'),('octets',bytes([0,127,255])),('counter-300k',deterministic_bytes(300000))]:
        s=MemoryStore();b=build(s,gear_chunks([data]));digest,n,oid=metadata(s,b.root);rt=_tree_for_test(s,b.root)
        vector.append({'name':label,'input':data.hex() if len(data)<100 else 'deterministic_bytes(300000)','length':n,'sha256':digest,'ogb_root_sha1':b.root,'meta_hex':s.objects[rt['meta'][1]][1].hex(),'chunks':[{'git_oid':x,'length':n} for x,n in b.chunks],'stored_reference_cbor':encode(stored_reference(digest,n)).hex()})
    answers={'version':'1.1.0','scope':'Reference-model known answers; not implementation conformance','gear_words_first_four':[f'{x:016x}' for x in GEAR[:4]],'vectors':vector}
    golden=R/'tests/blob-vectors.json'
    if golden.exists():
        if json.loads(golden.read_text()) != answers:
            raise SystemExit('Frozen blob vectors disagree with the reference model; review, do not silently overwrite.')
    else:
        golden.write_text(json.dumps(answers,indent=2)+'\n')
    raise SystemExit(0 if result.wasSuccessful() else 1)
