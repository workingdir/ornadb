#!/usr/bin/env python3
"""Produce a sorted ZIP of the completed source edition and exact hash manifests."""
from pathlib import Path
import argparse,hashlib,json,zipfile
R=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def files():
 return sorted(p for p in R.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.zip'})
def save(p,x):(R/p).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=R.parent/'Orna-1.1.0.zip');args=ap.parse_args()
 report=json.loads((R/'evidence/checks.json').read_text())
 if not report['all_passed']:raise SystemExit('Cannot package a failed check run')
 # Provenance of all active source/profile/corpus files, generated indexes included.
 parent=json.loads((R/'provenance/parent-file-index.json').read_text())['files']
 current={str(p.relative_to(R)):sha(p) for p in files() if p.relative_to(R).parts[0] in {'source','api','grammar','profiles','examples','tests'}}
 changes=[{'path':p,'change':'added' if p not in parent else 'modified','before_sha256':parent.get(p),'after_sha256':v} for p,v in current.items() if parent.get(p)!=v]
 save('provenance/file-changes.json',{'parent_archive_sha256':'5acd23c999881e3121bdb2addf55df161effd95c09a5d69b034cbc1b77038688','scope':'Active source/API/grammar/profile/corpus files; legacy PDFs, nested archives and previous execution reports are not republished as 1.1 evidence.','changes':changes,'omitted_active_parent_files':[p for p in parent if p not in current]})
 req=json.loads((R/'tests/requirements.json').read_text());sc=json.loads((R/'tests/scenarios.json').read_text());api=json.loads((R/'api/sys.json').read_text())
 # Normative source/profile/data inputs are distinguished from informative examples and observed evidence.
 normative={str(p.relative_to(R)):sha(p) for p in files() if p.relative_to(R).parts[0] in {'source','api','grammar','profiles'}}
 release={'publication':'Orna language, runtime and repository specification','version':'1.1.0','publication_date':'2026-10-04','kind':'specification-source-edition','status':'Specification; not an Orna engine release','parent_version':'1.0.0','parent_archive_sha256':'5acd23c999881e3121bdb2addf55df161effd95c09a5d69b034cbc1b77038688','chapters':len(json.loads((R/'source/manifest.json').read_text())),'requirements':len(req),'added_requirements':84,'scenario_oracles':sc['count'],'api':{'sys_version':api['sys_version'],'counts':api['counts']},'format_coordinates':{'repository':2,'blob':'OGB-1','repository_row':'ORR-2','repository_value':'ROV-2','semantic_value':'SOV-2','compact':'compact-storage-v2','portable_value':'OVB-1','live_protocol':'orna.present.v1'},'implementation_execution':'not-executed','reference_evidence':'evidence/checks.json','implementation_goal':'implementation/ORCHESTRATOR.md','normative_payload_count':len(normative),'normative_payload_sha256':normative,'publications':[{'file':'Orna-1.1.0.md','sha256':sha(R/'Orna-1.1.0.md')},{'file':'index.html','sha256':sha(R/'index.html')}],'archive_reproducibility':'Sorted names and fixed ZIP metadata produce identical archives from the same completed payloads. Re-running toolchains or observed tests may change generated evidence.'}
 save('release.json',release)
 exclude={'file-manifest.json','SHA256SUMS'}
 manifest={str(p.relative_to(R)):{'size':p.stat().st_size,'sha256':sha(p)} for p in files() if str(p.relative_to(R)) not in exclude}
 save('file-manifest.json',{'version':'1.1.0','self_exclusions':sorted(exclude),'files':manifest})
 (R/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.relative_to(R)}\n' for p in files() if p.name!='SHA256SUMS'))
 args.output.parent.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(args.output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in files():
   info=zipfile.ZipInfo('Orna-1.1.0/'+str(p.relative_to(R)),date_time=(2026,10,4,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;info.create_system=3
   z.writestr(info,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
 checksum=args.output.with_suffix(args.output.suffix+'.sha256');checksum.write_text(sha(args.output)+'  '+args.output.name+'\n')
 print(f'{args.output}: {args.output.stat().st_size} bytes, {len(files())} files, sha256 {sha(args.output)}')
if __name__=='__main__':main()
