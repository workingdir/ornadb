# Orna 1.1.0 validation boundary

This publication contains checked authoring inputs, reference models and a separate native-Git experiment. **It is not an implementation conformance report for OrnaDB.** Every requirement-to-implementation entry remains `not-executed` until an actual Orna implementation supplies revision-pinned evidence.

## Executed check categories

| Check | What it establishes | What it does not establish |
|---|---|---|
| `tools/validate.py` | Source requirement inventory; API additions and retained signatures; profile/schema/fixture links; unchanged EBNF and live registry; generated HTML links. | Runtime semantics, all logical contradictions, or complete implementation coverage. |
| `tools/syntax_probe.py` | 172 independent snippet parse expectations against the bounded EBNF probe. | Orna resolution, types, effects, Unicode/interpolation completeness or execution. |
| `tools/test_blob_model.py` | 15 selected byte/identity/tree/range/codec/chunk invariants and frozen known answers. | Bounded production memory, concurrency, engine row admission or crash safety. |
| `tools/git_blob_proof.py` | 9 isolated real-Git reachability, partial clone, range hydration, GC pin, offline restore and submodule-boundary cases. | Production storage integration, concurrent destructive GC, hosted-remote policy, large-scale performance or network security. |
| `tools/make_media_fixtures.py` | Exact original 1-pixel PNG and PCM WAV bytes; their metadata expectations. | Native Orna decoder implementation or universal media format support. |
| Existing float/path/protocol models | Selected retained profile vectors and five structural/state protocol models. | A complete value codec, authenticated client/server or malformed-frame campaign. |

The native-Git proof uses synthetic data. A 128 KiB requested range may fetch a larger whole Git chunk; `git-blob-proof.json` records the actual payload. Its metadata is also data with a transfer cost. No compression ratio, constant-size clone, media re-encoding deduplication or unlimited retention guarantee follows from this experiment.

## Implementation gates still required

The orchestrator must execute the new scenarios through the actual production evaluator and persistent store; prove lazy rows/nested values and unchanged portable encodings; independently decode the Parquet profile; inject crashes across BLOB-CAPTURE-1/PUB-1/UPGRADE-2; exercise ownership and GC races; prove guarded index publication; test the minimal real application in a browser and a second renderer; verify privacy, quotas, and recursively complete offline copies. The old 1.0 requirements remain applicable to their classes.

A test oracle is not a pass. A skipped/unavailable prerequisite is not a pass. A model matching this specification is not an independent implementation. New library APIs marked illustrative are not represented as compiled artifacts.

Run `python tools/run_checks.py` to regenerate scoped results. After final packaging, `python tools/verify_release.py` verifies every shipped byte against the release file manifest without modifying it.
