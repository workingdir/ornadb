# Design sanity review — Orna 1.1.0

The review resolves the following architecture decisions in the normative source. It is not a guarantee of absence of defects and not an executed production test.

| Risk | 1.1 decision | Required implementation proof |
|---|---|---|
| Losing the executable Git database | Retain source/schema/row/dependency snapshots, partial clone and Git submodule pins. | Execute matching historical source and data, not today's code on old rows. |
| Treating Blob as a mutable file identity | Blob is immutable bytes; a table key identifies a row. Existing source File catalogue is separate. | Ordinary/nested `content: Blob` fields and replacement history. |
| Git layout changes becoming logical edits | Raw-content SHA-256/length is independent of chunk/tree OIDs. | Same bytes in differing layouts, including cross-hash-mode Git. |
| LFS or a second content store | Bounded ordinary Git blobs connected through real native trees. | Ordinary Git reachability/transfer and offline restoration. |
| Fake laziness | Reference values survive evaluation, equality, row hashing and inspection. | Track payload reads/allocation on metadata-only updates. |
| Incompatible hidden wire references | OVB-1/live remain unchanged; only ORR-2/ROV-2/SOV-2 admit commitments. | Reject storage tag 60100 at all portable boundaries. |
| Hash-only false equality/corruption | Distinguish claimed commitment, selected-chunk validation and full verification. | Corruption/collision/unavailable cases and exact byte comparison where required. |
| Descriptor ambiguity or excessive allocation | Explicit bounded CBOR shape, tree modes/names, fan-out/heights/offsets and chunk limits. | Negative corpus plus fuzzing/independent readers. |
| Metadata edits rereading old media | Format-2 row identity substitutes content commitments; v1 identities remain untouched. | Nested Blob/compact mixed-profile updates without payload reads. |
| Import acknowledged before durable bytes | Quarantine/install protection, native pin, then row/dependency transaction. | Crash injection at every handoff and coordinated GC. |
| Cleanup breaks in-flight or uncommitted data | Owners, pins, journals and pending tails are retained together. | Competing capture/publication/maintenance fault campaign. |
| Git index or submodule damage | Private candidate closure plus protected PUB-1/CAS/reconciliation; guarded review. | Partial staging, later tails, detached/unborn HEAD, submodule edits and stale candidates. |
| “Merging” a recording by concatenating chunks | Binary values merge as whole logical contents; divergent replacement conflicts. | Three-way semantic merge and post-merge verification. |
| Snapshot conversion rewrites prior history | Explicit repository format 2 in a new upgrade commit; mixed old/new readers. | UPGRADE-2 rollback/restart and old commit byte identity. |
| Metadata as a hidden second database | Intrinsics, decoded facts and persisted observations remain distinct. | Bounded decoder inputs/provenance and ordinary result tables. |
| Inspecting a photo runs paid inference | Explicit policy and all-input provenance for external analysis. | No implicit upload/cost/execution from default inspection. |
| “Minimal UI” quietly grows another framework | Table list, shared inspector, multiline input, Run and manual refresh. | Real end-to-end evaluator/storage, not simulated browser data. |
| CSS/JS become devtools-specific primitives | Snapshot-owned package resources or ordinary Blob rows; reusable responses. | Remove CSS; change source/assets; use another application/renderer. |
| Compulsory `File`/`Asset` system table | No such new registry; package/application metadata is ordinary data. | Import/query media with no devtools installed. |
| Browser code duplicates Orna | Optional evaluator-in-Wasm route, generated platform adapter only. | Actual target/import audit and source-authored rendering. |
| REPL state is mistaken for reactive slots | Immutable explicit state transitions; isolated console bindings. | Closure capture unchanged and new drafts preserved. |
| Restart silently repeats operations | Existing request identities/status and scoped session ownership. | Lost-result/restart/expired-session cases, no transcript replay. |
| Sparse clone treated as confidentiality | Raw Git clients are repository-trusted; app-only access uses admitted interfaces. | Perimeter/content checks and credential segregation. |
| Parent clone called a complete copy | Walk required pinned dependency repositories separately; report missing promises. | Disconnect all origins and retrieve original bytes. |
| History called unlimited/free | Reachable ancestry retains content; no guarantee for arbitrary re-encoding or host quotas. | Scale/hydration/retention measurements and explicit rewrite policy. |

## What the included execution establishes

The Python tests cover selected data-format invariants. The isolated Git proof confirms object reachability, selective blob hydration, sequential pin retention, exact offline byte restoration and the separate submodule-copy boundary. The EBNF probe checks syntax expectations. Static validators check the authored inventories, unchanged base contracts and publication links. None of these stand in for the production proofs in the right-hand column.

The remaining engineering is stated as open implementation work in `implementation/ORCHESTRATOR.md` and `tests/requirement-evidence.json`, not resolved by asserting that the design is airtight.
