#!/usr/bin/env python3
"""Write the complete structural live-message registry and HTTP JSON schemas.
The CBOR registry uses explicit descriptive types, not JSON coercions of CBOR.
"""
from pathlib import Path
import json
R=Path(__file__).resolve().parents[1]
messages=[
(0,'client','subscribe','null',{0:'bytes16',1:'PresentationContext'},{}),
(1,'client','unsubscribe','required',{},{}),(2,'client','resync','required',{},{}),
(3,'client','event','required',{0:'UInt',1:'bytes16',2:'TypedValue',3:'bytes32'},{}),
(4,'client','eval','null',{0:'Str',1:'DatabaseContext',2:'PresentationContext',3:'bytes32'},{}),
(5,'client','watch','null',{0:'Str',1:'DatabaseContext',2:'PresentationContext'},{3:'NonnegativeDuration'}),
(6,'client','cancel','null',{0:'TargetKind',1:'bytes16'},{}),
(7,'client','request_status','null',{0:'bytes16',1:'bytes32'},{}),
(16,'host','snapshot','required',{0:'UInt',1:'PresentNode',2:'Snapshot'},{}),
(17,'host','delta','required',{0:'UInt',1:'UInt',2:'PatchList',3:'Snapshot'},{}),
(18,'host','result','null',{0:'ResultStatus',1:'TypedValueOrNull',2:'bytes32',3:'DiagnosticOrNull'},{}),
(19,'host','diagnostic','optional',{0:'Diagnostic'},{1:'Bool'}),
(20,'host','request_status_result','null',{0:'bytes16',1:'RequestState',2:'bytes32?',3:'ResultBody?'},{})]
registry={'profile':'orna.present.v1','value_profile':'OVB-1','envelope':{'required':{'0':'constant UInt 1','1':'UInt16 message type','2':'bytes16 or null request','3':'bytes16 or null watch','4':'body map'},'unknown_keys':'reject'},'body_extensions':{'optional_unknown_range':[0,32767],'mandatory_unknown_range':[32768,65535],'fingerprint_includes_all_fields':True},'messages':[]}
for code,direction,name,watch,required,optional in messages:
 request='required' if direction=='client' or name in ['result','request_status_result'] else ('null' if name=='delta' else 'optional')
 registry['messages'].append({'code':code,'direction':direction,'name':name,'request':request,'watch':watch,'required':required,'optional':optional})
registry['definitions']={
'UInt':'An untagged CBOR integer >= 0; Bool is not an integer.',
'bytes16':'A CBOR byte string with exactly 16 bytes; never text.',
'bytes32':'A CBOR byte string with exactly 32 bytes.',
'DatabaseContext':{'required':{'0':'Uuid','1':'Snapshot?'},'unknown_keys':'reject'},
'PresentationContext':{'required':{'0':'Str','1':'Str?','2':'PositiveUInt?','3':'Str','4':'[Str]'},'unknown_keys':'reject'},
'TargetKind':[0,1],'ResultStatus':[0,1,2,3],'RequestState':[0,1,2,3,4],
'Snapshot':'Exact structure in the canonical value profile; a bare [0] is invalid.',
'PresentNode':'Tag 60012 around [kind, stable_key_or_null, properties, children].',
'Diagnostic':'Tag 60011 around the required diagnostic map; severity 0..4.',
'TypedValue':'Schema-directed OVB-1 application value, never a structural null.',
'NonnegativeDuration':'Tag 60005 around [floor_seconds, nanosecond], with seconds >= 0 and 0 <= nanosecond < 1000000000.',
'PatchList':'Ordered operations and typed paths from the live protocol chapter.'}
(R/'profiles/live-messages.json').write_text(json.dumps(registry,indent=2)+'\n')
uuid={'type':'string','pattern':r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'}
protocol={'const':'orna.present.v1'}
token={'type':'string','pattern':r'^[A-Za-z0-9_-]{43}$'}
limits={'type':'object','required':['max_message_bytes','max_depth','max_nodes','max_collection_items','max_outgoing_bytes','request_retention_ms'],'properties':{k:{'type':'integer','minimum':v} for k,v in [('max_message_bytes',16777216),('max_depth',64),('max_nodes',100000),('max_collection_items',1),('max_outgoing_bytes',1),('request_retention_ms',1)]},'additionalProperties':False}
def obj(p):return {'type':'object','required':list(p),'properties':p,'additionalProperties':False}
schema={'$schema':'https://json-schema.org/draft/2020-12/schema','title':'Orna live-session HTTP JSON structures','description':'Select one $defs entry. Duplicate JSON members must be rejected before schema validation. Validate token base64 canonical bits, matching path/session IDs and retention >= lease separately.','oneOf':[{'$ref':'#/$defs/create_request'},{'$ref':'#/$defs/resume_request'},{'$ref':'#/$defs/session_response'}],'$defs':{'create_request':obj({'database':uuid,'protocol':protocol}),'resume_request':obj({'resume_token':token,'protocol':protocol}),'session_response':obj({'session':uuid,'database':uuid,'runtime':uuid,'resume_token':token,'websocket_path':{'type':'string','pattern':r'^/orna/live/[0-9a-fA-F-]{36}$'},'lease_ms':{'type':'integer','minimum':1},'limits':limits})}}
(R/'profiles/session.schema.json').write_text(json.dumps(schema,indent=2)+'\n')
print('13 live messages; 3 closed HTTP structures')
