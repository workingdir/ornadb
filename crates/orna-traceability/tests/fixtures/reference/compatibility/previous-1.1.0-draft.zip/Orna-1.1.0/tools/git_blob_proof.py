#!/usr/bin/env python3
"""Isolated real-Git experiment for OGB-1. Does not execute Orna or alter a user repo."""
from __future__ import annotations
from pathlib import Path
import hashlib,json,os,subprocess,tempfile,time
from blob_model import *
R=Path(__file__).resolve().parents[1]
ENV=os.environ.copy()
for k in list(ENV):
    if k.startswith('GIT_'):ENV.pop(k)
ENV.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':os.devnull,'GIT_TERMINAL_PROMPT':'0',
            'GIT_AUTHOR_NAME':'Orna reference test','GIT_AUTHOR_EMAIL':'test@example.invalid',
            'GIT_COMMITTER_NAME':'Orna reference test','GIT_COMMITTER_EMAIL':'test@example.invalid',
            'GIT_AUTHOR_DATE':'2026-10-04T00:00:00Z','GIT_COMMITTER_DATE':'2026-10-04T00:00:00Z'})

def git(repo,*args,input=None,check=True):
    p=subprocess.run(['git','-C',str(repo),*args],input=input,capture_output=True,env=ENV,timeout=45)
    if check and p.returncode:raise RuntimeError('git '+args[0]+' failed: '+p.stderr.decode(errors='replace')[-1200:])
    return p

class GitStore:
    def __init__(self,repo,algorithm='sha1'):
        self.repo=repo;self.algorithm=algorithm;self.reads=[]
    def put(self,kind,data):
        return git(self.repo,'hash-object','-t',kind,'-w','--stdin',input=data).stdout.decode().strip()
    def get(self,oid):
        self.reads.append(oid)
        t=git(self.repo,'cat-file','-t',oid,check=False)
        if t.returncode:raise BlobError('unavailable Git object')
        kind=t.stdout.decode().strip();data=git(self.repo,'cat-file',kind,oid).stdout
        if object_id(kind,data,self.algorithm)!=oid:raise BlobError('Git hash mismatch')
        return kind,data
    def tree(self,entries):return self.put('tree',tree_bytes(entries,self.algorithm))

def local_objects(repo):
    p=git(repo,'cat-file','--batch-all-objects','--batch-check=%(objectname) %(objecttype)')
    return dict(line.split() for line in p.stdout.decode().splitlines())

def snapshot(store,content:Built,title:str,parent:str|None=None):
    row=('{'+' title: '+json.dumps(title)+', content: { blob: "sha256:'+content.digest+'", length: '+str(content.length)+' }, }\n').encode()
    song=store.tree({'song.orna':('blob',store.put('blob',row))})
    rows=store.tree({'Song':('tree',song)})
    shard=store.tree({content.digest[2:]:('tree',content.root)})
    blobs=store.tree({content.digest[:2]:('tree',shard)})
    marker=b'{ repository_format: 2, row_profile: "ORR-2", blob_profile: "OGB-1", semantic_profile: "SOV-2", compact_profile: "compact-storage-v2", }\n'
    private=store.tree({'blobs':('tree',blobs),'format.orna':('blob',store.put('blob',marker))})
    root=store.tree({'.orna':('tree',private),'main.orna':('blob',store.put('blob',b'use music;\n')),
                     'music.orna':('blob',store.put('blob',b'pub table Song(id: Str) { title: Str, content: Blob, }\n')),
                     'music':('tree',rows)})
    args=['commit-tree',root]
    if parent:args+=['-p',parent]
    return git(store.repo,*args,input=(title+'\n').encode()).stdout.decode().strip()

def run():
    start=time.monotonic();results=[]
    def record(name,detail):results.append({'name':name,'passed':True,'detail':detail})
    with tempfile.TemporaryDirectory(prefix='orna-ogb-proof-') as tmp:
        base=Path(tmp);repo=base/'source';repo.mkdir();git(repo,'init','-q','-b','main')
        git(repo,'config','gc.auto','0');s=GitStore(repo)
        data=deterministic_bytes(8<<20);a=build(s,gear_chunks([data]));first=snapshot(s,a,'Original')
        second=snapshot(s,a,'Title changed',first)
        changed=data[:2_000_000]+b'new-recording-content'*200+data[2_000_000:]
        b=build(s,gear_chunks([changed]));third=snapshot(s,b,'Recording changed',second)
        git(repo,'update-ref','refs/heads/main',third)
        git(repo,'symbolic-ref','HEAD','refs/heads/main')
        git(repo,'fsck','--full','--no-reflogs')
        listed=git(repo,'rev-list','--objects',third).stdout.decode()
        assert all(oid in listed for oid,_ in a.chunks+b.chunks)
        record('native-reachability',{'source_bytes':len(data),'first_chunks':len(a.chunks),'all_chunks_reachable_from_commit':True})
        old_ids={oid for oid,_ in a.chunks};new_ids={oid for oid,_ in b.chunks}
        reused=sum(n for oid,n in b.chunks if oid in old_ids)
        record('metadata-and-content-history',{'metadata_only_new_media_chunks':0,'new_media_chunks':len(new_ids-old_ids),'reused_bytes_after_insertion':reused,'input_bytes':len(data)})
        # Text containing an object ID is not a native object graph edge.
        unattached=s.put('blob',b'not referenced except by textual hash')
        badroot=s.tree({'row.orna':('blob',s.put('blob',unattached.encode()))})
        badcommit=git(repo,'commit-tree',badroot,input=b'text-only reference\n').stdout.decode().strip()
        assert unattached not in git(repo,'rev-list','--objects',badcommit).stdout.decode()
        record('textual-hash-is-not-reachability',{'unattached_chunk_not_reachable':True})
        # A real protected local root survives sequential aggressive GC.
        pending=build(s,[b'unpublished row content'])
        pin=git(repo,'commit-tree',pending.root,input=b'local pin\n').stdout.decode().strip()
        pinref='refs/orna-local/blobs/test-runtime/test-import'
        git(repo,'update-ref',pinref,pin)
        git(repo,'gc','--prune=now')
        assert read_range(s,pending.root,0,100)==b'unpublished row content'
        record('pending-pin-retention',{'sequential_gc_prune_now_preserves_content':True,'concurrent_unsafe_gc_claimed':False})
        git(repo,'update-ref','-d',pinref)
        remote=base/'remote.git'
        git(base,'clone','--bare',str(repo),str(remote))
        git(remote,'config','uploadpack.allowFilter','true')
        git(remote,'config','uploadpack.allowReachableSHA1InWant','true')
        clone=base/'partial'
        git(base,'clone','--filter=blob:none','--no-checkout',remote.as_uri(),str(clone))
        obj0=local_objects(clone);blobs0={o for o,t in obj0.items() if t=='blob'}
        assert len(blobs0)==0
        # Resolve only source, row and content header; no media fetch.
        git(clone,'show','HEAD:main.orna');git(clone,'show','HEAD:music/Song/song.orna')
        cs=GitStore(clone);metadata(cs,b.root)
        obj1=local_objects(clone);assert not set(obj1)&new_ids
        offset=1_700_000;count=128<<10
        got=read_range(cs,b.root,offset,count);assert got==changed[offset:offset+count]
        obj2=local_objects(clone);hydrated=set(obj2)&new_ids
        ends=0;wanted=set()
        for oid,n in b.chunks:
            if ends<offset+count and ends+n>offset:wanted.add(oid)
            ends+=n
        assert hydrated==wanted
        record('real-partial-clone-and-range',{'initial_local_blobs':len(blobs0),'media_after_header':0,
             'range_bytes':count,'chunk_objects_fetched':len(hydrated),'chunk_bytes_fetched':sum(n for oid,n in b.chunks if oid in hydrated),
             'all_fetched_chunks_intersect_range':True,'metadata_and_trees_are_separate_costs':True})
        # No alternative storage service: a full mirror carries both content versions.
        mirror=base/'mirror.git';git(base,'clone','--mirror',remote.as_uri(),str(mirror))
        ms=GitStore(mirror);remote.rename(base/'remote-offline.git')
        assert verify(ms,a.root)==a.digest and verify(ms,b.root)==b.digest
        assert read_range(ms,a.root,0,len(data))==data
        # b is over the 8 MiB per-call limit: explicit bounded reads.
        restored=read_range(ms,b.root,0,MAX_READ)+read_range(ms,b.root,MAX_READ,b.length-MAX_READ)
        assert restored==changed
        git(mirror,'fsck','--full','--no-reflogs')
        record('offline-mirror-restoration',{'original_sha256':a.digest,'new_sha256':b.digest,'both_exact':True})
        missing=next(oid for oid,n in b.chunks if oid not in obj2)
        try:cs.get(missing)
        except BlobError:pass
        else:raise AssertionError('offline missing chunk unexpectedly available')
        record('offline-partial-unavailability',{'uncached_read_fails_not_empty':True})
        # SHA-256 repository object mode, independent of logical content hash.
        sha=base/'sha256';sha.mkdir();git(sha,'init','-q','--object-format=sha256')
        ss=GitStore(sha,'sha256');sblob=build(ss,[b'abc'])
        assert verify(ss,sblob.root)==hashlib.sha256(b'abc').hexdigest()
        record('native-sha256-repository',{'tree_oid_hex_length':len(sblob.root),'content_identity_algorithm':'sha256(raw bytes)'})
        # Submodule pin reachability belongs to a separate repository.
        sub=base/'std';sub.mkdir();git(sub,'init','-q','-b','main')
        (sub/'main.orna').write_text('pub fn twice(x: Int): Int = x + x;\n')
        git(sub,'add','main.orna');git(sub,'commit','-qm','pinned std')
        suboid=git(sub,'rev-parse','HEAD').stdout.decode().strip()
        parent=base/'dependency-parent';parent.mkdir();git(parent,'init','-q','-b','main')
        git(parent,'-c','protocol.file.allow=always','submodule','add','-q',str(sub),'stdlib/std')
        git(parent,'commit','-qm','dependency pin')
        parentmirror=base/'dependency-parent.git';git(base,'clone','--mirror',str(parent),str(parentmirror))
        assert git(parentmirror,'cat-file','-e',suboid,check=False).returncode!=0
        submirror=base/'std-copy.git';git(base,'clone','--mirror',str(sub),str(submirror))
        assert git(submirror,'cat-file','-e',suboid).returncode==0
        record('submodule-completeness-boundary',{'parent_mirror_does_not_contain_dependency_commit':True,'separate_dependency_copy_preserves_pin':True})
    return {'scope':'Isolated native Git transport/object experiment, not Orna engine or production crash/performance verification',
            'git_version':subprocess.check_output(['git','--version'],text=True).strip(),'passed':True,
            'test_count':len(results),'results':results,'elapsed_seconds':round(time.monotonic()-start,3)}

if __name__=='__main__':
    try:report=run()
    except Exception as exc:
        report={'passed':False,'scope':'real-Git reference experiment','error':str(exc)}
        (R/'evidence/git-blob-proof.json').write_text(json.dumps(report,indent=2)+'\n');raise
    (R/'evidence/git-blob-proof.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
