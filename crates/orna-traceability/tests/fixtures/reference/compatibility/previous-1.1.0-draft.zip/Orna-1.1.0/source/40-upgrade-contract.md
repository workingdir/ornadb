# 35. Compatibility, migration and verification {#upgrade}

## Release boundaries

Orna 1.1.0 retains the language's immutable values, relational identity, Git snapshots, partial-clone model, standard-library pins, embedded local state and existing live protocol. It adds concrete Git-native Blob storage, explicit Blob operations, ingestion/inspection boundaries and a deliberately minimal source-hosted application profile. It does not substitute a proprietary database history, require LFS, introduce a compulsory File/Asset table, or make a new UI framework a precondition of usable binary storage.

**ORNA-UPGRADE-001** An implementation MUST treat specification version, repository format, system API, value codec, compact segment profile and wire protocol as distinct coordinates. It MUST NOT infer one from a filename or simply change all `v1` labels to `v2`.

| Coordinate | Retained | Added/selected by this release |
|---|---|---|
| Language grammar | Same core source productions | Blob operations are ordinary callable names; ORR tokens are row-admission data. |
| Git history | Existing commits and OIDs | New commits only; no mandatory rewrite. |
| Repository | Read format 1 | Explicit format-2 opt-in; fresh 1.1 repositories default to 2. |
| Ordinary values/wire | OVB-1; canonical portable text | No Blob pointer substitution. |
| Repository values | Format-1 row/Parquet encodings | ORR-2 / ROV-2 and mixed-segment compact-storage-v2. |
| Row identity | Existing `orna.row.v1` values retained | `orna.row.v2` over SOV-2 for format-2 writes. |
| API | Existing sys operations retained | `sys_version: "1.1"`, appended Blob/guarded-commit operations. |
| Live protocol | `orna.present.v1`, existing HTTP session schema | Unchanged message fields, enum codes and fingerprint input. |
| Optional library | Explicit selected `std` snapshots | No global newest-library substitution; UI/media packages may evolve separately. |

## Format transition UPGRADE-2

1. Read the selected specification and actual repository format. Inventory ordinary index/worktree state, pending CWD data, active owners, submodules and required refs. Do not assume the repository is empty or clean.
2. Require a compatible 1.1 reader/verification implementation before making a format-2 write. Produce a preflight report describing new capabilities, changed physical files, unchanged logical rows and rollback point. Create a recoverable local backup/pin by the normal repository mechanisms.
3. Quiesce conflicting writers/publication. Refuse unresolved managed-path/index conflicts. In the first implementation, require pending format-1 runtime mutations to be safely published or explicitly preserved in a verified backup before conversion; never discard them or call a cache rebuild a migration.
4. Prepare the format-2 metadata and only the explicitly selected conversions in a private candidate. Old inline Blob values can remain inline until rewritten; existing format-1 compact segments retain their own version. Blob externalisation computes/validates content identity and native reachability first.
5. Validate source/schema/rows/assertions and compare logical values across old/new representations. Regenerate only the caches/identities whose version requires it. Historical consumers, request IDs, allocator monotonic state and old codec bytes are not silently rehashed.
6. Commit the upgrade through the same journal, native-object protection, branch CAS and index reconciliation as other administrative publication. A changed base invalidates the plan. Recovery follows the journal; it never edits old commits or restores HEAD over another person's newer work.
7. Record the format transition and execute the migration, offline-copy and mixed-history tests. Rollback before visibility discards only new candidate work. Reverting to a reader that cannot understand format 2 is not safe after new-format writes; use a new branch at the old commit or an explicit lossless downgrade/export plan.

**ORNA-UPGRADE-002** Upgrade MUST preserve historical source, schema and bytes under their original format coordinates and MUST NOT claim a lossless downgrade by changing only `format.orna`. Semantic equality across the transition uses decoded values; differing digest-profile versions are not row changes.

**ORNA-UPGRADE-003** A client without a required repository/profile reader MUST fail before interpreting its values or writing the snapshot. A materialised portable OVB-1 value remains compatible where its length is admitted, but that does not make the same client a format-2 repository reader.

**ORNA-UPGRADE-004** Existing postponed features from 1.0 MUST NOT be relabelled complete by this release. The implementation orchestrator MUST first produce a small actual Blob/row/UI path, then close the remaining requirements for the conformance classes it claims. First-milestone success is not full 1.1 completion.

## Correcting two inherited fixtures

The inherited valid fixtures `failure-natural-key.orna` and `stream-admin-repl.orna` omitted the `expected_version` required by the existing administrative signatures. This release inserts `expected_version: failure.version` in each fixture. It does not weaken version checking or modify the old archive. The inherited `MIGRATE-SURFACE-091` scenario also linked to the nonexistent `ORNA-MIGRATE-001`; that dangling link is removed while its existing migration/diagnostic requirements remain. Their old source hashes are recorded in provenance and their 1.1 expectations remain runtime-unexecuted until an engine runs them.

**ORNA-UPGRADE-005** Fixing a publication fixture MUST NOT be implemented as a weakened safety check, skipped conformance phase or silently changed runtime semantic. The release's fixture change record and effective API are the authority for these corrections.

## Required proof matrix

`tests/blob-scenarios.json` identifies positive, negative, failure and integration cases. `tests/blob-vectors.json` supplies reference encoding/chunk/range answers. The Python model and real-Git experiment are independent authoring checks, not the implementation under test.

**ORNA-UPGRADE-006** Full Blob/repository conformance MUST execute its tests through the production evaluator, table store, publisher, reader and remote transport. A Git plumbing demonstration or codec unit test MUST NOT be relabelled as whole-engine execution.

**ORNA-UPGRADE-007** Verification MUST distinguish: declared content commitment; structurally validated descriptors; locally verified chunks/ranges; fully verified content; and complete dependency closure. An online partial clone and an offline-complete repository MUST have distinguishable status. Unavailable promised content is neither empty data nor proof of corruption by itself.

**ORNA-UPGRADE-008** Release evidence MUST state commands, tool versions, input/publication digests, observed outcomes and scope. Unexecuted crash, Parquet, browser, evaluator or load tests remain explicitly unexecuted. No statement that the design is defect-free follows from authoring checks.
