# Publication provenance

This source edition is derived from the user-supplied `Orna-1.0.0(2).zip`.

Parent archive SHA-256:

```text
5acd23c999881e3121bdb2addf55df161effd95c09a5d69b034cbc1b77038688
```

The parent archive is not modified and is not recursively copied into the release. Historical PDFs, screenshots, nested ZIPs and old execution reports are omitted rather than relabelled 1.1.0. The original user-supplied content retains its existing ownership; this edition does not invent a new licence grant over it.

`parent-contract.json` records the retained grammar/live-profile hashes, legacy operation declarations and all 870 existing requirement IDs. `parent-file-index.json` and `parent-requirements.json` retain exact prior hash/requirement inventories. `requirement-changes.json` separates additions from revised wording and removals. `file-changes.json` records the prior/current hashes of active source/API/profile/corpus files. `1.0.0-to-1.1.0.patch` is a textual review aid for source/API/grammar/profile changes; canonical current files, not applying a patch blindly, define 1.1.0.

The fixture corrections are limited and attributable: add `expected_version: failure.version` to the two inherited valid failure-admin fixtures, and remove a dangling scenario reference to nonexistent `ORNA-MIGRATE-001`. This does not weaken the existing CAS or migration semantics. Publication-only broken anchors are repaired.

There are no current engine passes inherited from the earlier edition. The checked-in Python/Git/authoring evidence was executed for this source tree and is explicitly scoped. Browser/engine/crash/Parquet/scale acceptance remains implementation work. New APIs and storage profiles are specified contracts, not claims that the existing Orna binary accepts them.

Check `SHA256SUMS` and `file-manifest.json` for exact release payload integrity. The package checksum beside the ZIP is transport verification, not a signature or proof of the specification's correctness.
